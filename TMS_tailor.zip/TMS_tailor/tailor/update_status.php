<?php
require_once('function.php');
dbconnect();

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'];
$status = $data['status'];

// Update the status in the database
$stmt = $pdo->prepare("UPDATE customer SET status = :status WHERE id = :id");
$stmt->execute(['status' => $status, 'id' => $id]);
