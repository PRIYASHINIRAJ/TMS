<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

$user = $_SESSION['username'];
$usid = $pdo->query("SELECT id FROM users WHERE username='" . $user . "'");
$usid = $usid->fetch(PDO::FETCH_ASSOC);
$uid = $usid['id'];
include('header.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Change ADMIN Password</title>
    <link rel="stylesheet" href="css/style.default.css">
    <style>
        .content-wrapper {
            margin: 20px;
            background-color: #f4f4f4;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-container {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
        }

        .form-group input:focus {
            border-color: #80bdff;
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }

        .btn-submit {
            background-color: #28a745;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-submit:hover {
            background-color: #218838;
        }

        .alert {
            padding: 15px;
            border: 1px solid transparent;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }

        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }

        .page-header {
            margin-bottom: 30px;
        }

        .page-header h1 {
            font-size: 2rem;
            color: #343a40;
        }

        .tips {
            background-color: #e9ecef;
            padding: 10px;
            border-radius: 5px;
            margin-top: 20px;
        }

        .tips ul {
            list-style: none;
            padding: 0;
        }

        .tips ul li {
            margin-bottom: 10px;
            color: #333;
        }

        .tips ul li i {
            color: #17a2b8;
            margin-right: 10px;
        }

    </style>
</head>
<body>
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Change ADMIN Password</h1>
            </div>
        </div>
        <div class="row content-wrapper">
            <div class="col-md-8 col-md-offset-2 form-container">
                <?php
                if ($_POST) {
                    $oldword = $_POST["oldword"];
                    $newword = $_POST["newword"];
                    $newwword = $_POST["newwword"];

                    $oldmd = MD5($oldword);

                    $cpass = $pdo->query("SELECT password FROM users WHERE id='" . $uid . "'");
                    $cpass = $cpass->fetch(PDO::FETCH_ASSOC);

                    $err1 = 0; $err2 = 0; $err3 = 0; $err4 = 0;

                    if ($oldmd != $cpass['password']) {
                        $err1 = 1;
                    }

                    if ($newword != $newwword) {
                        $err2 = 1;
                    }

                    if (trim($newword) == "") {
                        $err3 = 1;
                    }

                    if (strlen($newword) <= 3) {
                        $err4 = 1;
                    }

                    $error = $err1 + $err2 + $err3 + $err4;

                    if ($error == 0) {
                        $passmd = MD5($newword);
                        $res = $pdo->exec("UPDATE users SET password='" . $passmd . "' WHERE id='" . $uid . "'");
                        if ($res) {
                            echo "<div class='alert alert-success alert-dismissable'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>    
                            Password Updated Successfully!
                            </div>";
                        } else {
                            echo "<div class='alert alert-danger alert-dismissable'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>    
                            Some Problem Occurred, Please Try Again. 
                            </div>";
                        }
                    } else {
                        if ($err1 == 1) {
                            echo "<div class='alert alert-danger alert-dismissable'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>    
                            Your Current Password Does Not Match.
                            </div>";
                        }
                        if ($err2 == 1) {
                            echo "<div class='alert alert-danger alert-dismissable'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>    
                            You Entered Different Passwords in the two fields. Please enter the same password in both fields.
                            </div>";
                        }
                        if ($err3 == 1) {
                            echo "<div class='alert alert-danger alert-dismissable'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>    
                            Password Cannot Be Empty!!!
                            </div>";
                        }
                        if ($err4 == 1) {
                            echo "<div class='alert alert-danger alert-dismissable'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>    
                            Password Must Be 4 or more characters.
                            </div>";
                        }
                    }
                }
                ?>
                <form action="changepass.php" method="post">
                    <div class="form-group">
                        <label>Current Password</label>
                        <input class="form-control" placeholder="Current Password" name="oldword" type="password">
                    </div>
                    <div class="form-group">
                        <label>New Password</label>
                        <input class="form-control" placeholder="New Password" name="newword" type="password">
                    </div>
                    <div class="form-group">
                        <label>New Password Again</label>
                        <input class="form-control" placeholder="New Password Again" name="newwword" type="password">
                    </div>
                    <input type="submit" class="btn btn-submit btn-block" value="Change">
                </form>
                <div class="tips">
                    <h4>Password Tips:</h4>
                    <ul>
                        <li><i class="fas fa-check-circle"></i>Use a combination of uppercase and lowercase letters.</li>
                        <li><i class="fas fa-check-circle"></i>Include numbers and special characters.</li>
                        <li><i class="fas fa-check-circle"></i>Avoid using common words or easily guessable information.</li>
                        <li><i class="fas fa-check-circle"></i>Make sure your new password is at least 8 characters long.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <?php include('footer.php'); ?>

    <script src="js/jquery.datatables.min.js"></script>
    <script src="js/select2.min.js"></script>
    <script src="js/bootstrap-timepicker.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script>
        jQuery(document).ready(function(){
            "use strict";

            jQuery('#table1').dataTable();
            jQuery('#table2').dataTable({
                "sPaginationType": "full_numbers"
            });

            // Select2
            jQuery('select').select2({
                minimumResultsForSearch: -1
            });
            jQuery('select').removeClass('form-control');

            // Delete row in a table
            jQuery('.delete-row').click(function(){
                var c = confirm("Continue delete?");
                if(c)
                    jQuery(this).closest('tr').fadeOut(function(){
                        jQuery(this).remove();
                    });
                return false;
            });

            // Show action upon row hover
            jQuery('.table-hidaction tbody tr').hover(function(){
                jQuery(this).find('.table-action-hide a').animate({opacity: 1});
            },function(){
                jQuery(this).find('.table-action-hide a').animate({opacity: 0});
            });

            // Time Picker
            jQuery('#timepicker').timepicker({defaultTIme: false});
            jQuery('#timepicker2').timepicker({showMeridian: false});
            jQuery('#timepicker3').timepicker({minuteStep: 15});
        });
    </script>
</body>
</html>
