<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tailor";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch data
$sql = "SELECT product_name, quantity FROM inventory";
$result = $conn->query($sql);

$productNames = [];
$quantities = [];

if ($result->num_rows > 0) {
    // Fetch data
    while ($row = $result->fetch_assoc()) {
        $productNames[] = $row["product_name"];
        $quantities[] = $row["quantity"];
    }
} else {
    echo json_encode(['error' => 'No results from the database']);
    exit;
}
$conn->close();

// Return data as JSON
header('Content-Type: application/json');
echo json_encode(['productNames' => $productNames, 'quantities' => $quantities]);
exit;
?>
