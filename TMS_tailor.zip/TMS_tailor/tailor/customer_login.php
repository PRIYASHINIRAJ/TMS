<?php
session_start();

// Include database connection
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate and sanitize inputs (you can add more validation as needed)
    $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);

    // Prepare and execute SQL query to fetch user from 'password' table
    $sql = "SELECT id, fullname, email, phone, password FROM `password` WHERE email = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verify password and start session if login is successful
    if ($user && password_verify($password, $user['password'])) {
        // Store user data in session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['phone'] = $user['phone'];

        // Redirect to order tracking page
        header("Location: order_tracking.php");
        exit();
    } else {
        // Redirect back to login page with error message
        header("Location: signup.php?error=Invalid%20email%20or%20password");
        exit();
    }
}
?>
