<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

$user = $_SESSION['username'];
$query = $pdo->query("SELECT id FROM users WHERE username='".$user."'");
if ($query === false) {
    die("Query failed: " . print_r($pdo->errorInfo(), true));
}
$usid = $query->fetch(PDO::FETCH_ASSOC);
if (!$usid) {
    die("No user found with the username: " . htmlspecialchars($user));
}
$uid = $usid['id'];
include('header.php');

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $deleteQuery = $pdo->exec("DELETE FROM `order` WHERE id='$id'");
    if ($deleteQuery === false) {
        die("Delete failed: " . print_r($pdo->errorInfo(), true));
    }
    echo "<div class='alert alert-success alert-dismissable'>
    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>    
    Order Deleted Successfully!
    </div>";
}
?>

<link href="css/style.default.css" rel="stylesheet">
<link href="css/jquery.datatables.css" rel="stylesheet">
<!-- DataTables CSS -->
<link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">
<!-- DataTables Responsive CSS -->
<link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">

<style>
    body {
        background: #f5f5f5;
        font-family: 'Roboto', sans-serif;
    }

    #page-wrapper {
        padding: 20px;
        background: #fff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }

    .page-header {
        margin-top: 0;
        font-size: 24px;
        color: #333;
        border-bottom: 1px solid #ddd;
        padding-bottom: 10px;
    }

    .panel {
        border: none;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }

    .panel-body {
        padding: 20px;
    }

    .table {
        margin-bottom: 0;
    }

    .table thead th {
        background: #6e8efb;
        color: #fff;
        border: none;
        text-transform: uppercase;
        font-size: 14px;
    }

    .table tbody tr {
        transition: all 0.3s;
    }

    .table tbody tr:hover {
        background: #f0f0f0;
    }

    .table tbody td {
        vertical-align: middle;
    }

    .btn {
        margin-right: 5px;
    }

    .btn-xs {
        padding: 5px 10px;
        font-size: 12px;
    }

    .alert {
        margin-bottom: 20px;
        border: none;
        border-radius: 5px;
    }

    .alert-success {
        background: #28a745;
        color: #fff;
    }

    .alert-danger {
        background: #dc3545;
        color: #fff;
    }

    @media (max-width: 768px) {
        #page-wrapper {
            padding: 10px;
        }

        .table-responsive {
            margin-bottom: 20px;
        }

        .btn-xs {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }
    }
</style>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">View Orders</h1>
        </div>
    </div>

    <div class="panel panel-default">
        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-striped" id="table2">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Description</th>
                            <th>Date Received</th>
                            <th>Amount</th>
                            <th>Balance</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $ordersQuery = $pdo->query("SELECT id, customer, description, date_received, amount, paid FROM `order` ORDER BY id DESC");
                        if ($ordersQuery === false) {
                            die("Query failed: " . print_r($pdo->errorInfo(), true));
                        }
                        while ($data = $ordersQuery->fetch(PDO::FETCH_ASSOC)) {
                            $customerQuery = $pdo->query("SELECT fullname FROM customer WHERE id='".$data['customer']."'");
                            if ($customerQuery === false) {
                                die("Query failed: " . print_r($pdo->errorInfo(), true));
                            }
                            $rname = $customerQuery->fetch(PDO::FETCH_ASSOC);
                            if (!$rname) {
                                $rname['fullname'] = 'Unknown';
                            }
                            $balance = $data['amount'] - $data['paid'];
                            echo "<tr>
                                <td>{$data['id']}</td>
                                <td>{$rname['fullname']}</td>
                                <td>{$data['description']}</td>
                                <td>{$data['date_received']}</td>
                                <td>{$currency} {$data['amount']}</td>
                                <td>{$currency} {$balance}</td>
                                <td>
                                    <a href='addpayment.php?id={$data['id']}' class='btn btn-success btn-xs'>Add Payment</a>
                                    <a href='printinvoice.php?id={$data['id']}' class='btn btn-warning btn-xs'>Receipt</a>
                                    <a href='orderedit.php?id={$data['id']}' class='btn btn-info btn-xs'>Update</a>
                                    <a href='orderlist.php?id={$data['id']}'><button type='button' class='btn btn-danger btn-xs'>DELETE</button></a>
                                </td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<script src="js/jquery.datatables.min.js"></script>
<script src="js/select2.min.js"></script>
<script>
    jQuery(document).ready(function() {
        "use strict";

        jQuery('#table2').dataTable({
            "sPaginationType": "full_numbers"
        });

        jQuery('select').select2({
            minimumResultsForSearch: -1
        });

        jQuery('select').removeClass('form-control');

        jQuery('.delete-row').click(function(){
            var c = confirm("Continue delete?");
            if (c)
                jQuery(this).closest('tr').fadeOut(function(){
                    jQuery(this).remove();
                });

            return false;
        });

        jQuery('.table-hidaction tbody tr').hover(function(){
            jQuery(this).find('.table-action-hide a').animate({opacity: 1});
        }, function(){
            jQuery(this).find('.table-action-hide a').animate({opacity: 0});
        });
    });
</script>
</body>
</html>
