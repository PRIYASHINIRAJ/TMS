<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

// Fetch all data from the customer table
$stmt = $pdo->prepare("SELECT fullname, comment FROM customer");
$stmt->execute();
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Filter customers for the TODO swim-lane
$customers_todo = array_filter($customers, function ($customer) {
    // Replace this condition with your logic to filter based on swim-lane or any other criterion
    // For example, if you have a status field in your table, you can check that here
    // Example: return $customer['status'] === 'TODO';
    return true; // Placeholder for filtering logic
});
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kanban Board</title>
    <link rel="stylesheet" href="styles.css" />
    <script src="drag.js" defer></script>
    <script src="todo.js" defer></script>
</head>
<body>
    <?php include('header.php'); ?>

    <div class="board">
        <form id="todo-form">
            <input type="text" placeholder="New TODO..." id="todo-input" />
            <button type="submit">Add +</button>
        </form>

        <div class="lanes">
            <div class="swim-lane" id="todo-lane">
                <h3 class="heading">TODO</h3>
                <?php foreach ($customers_todo as $customer) : ?>
                    <div class="task" draggable="true">
                        <p class="customer-name"><?= htmlspecialchars($customer['fullname']) ?></p>
                        <p class="comment"><?= htmlspecialchars($customer['comment']) ?></p>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="swim-lane">
                <h3 class="heading">Doing</h3>
                <!-- Leave this swim-lane empty for now -->
            </div>

            <div class="swim-lane">
                <h3 class="heading">Done</h3>
                <!-- Leave this swim-lane empty for now -->
            </div>
        </div>
    </div>

    <?php include('footer.php'); ?>
</body>
</html>
