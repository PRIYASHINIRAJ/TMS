<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Tracking</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-image: url('background-image.jpg'); /* Replace with your background image URL */
            background-size: cover; /* Cover entire background */
            background-position: center center; /* Center align horizontally and vertically */
            height: 100vh; /* Full viewport height */
            display: flex;
            align-items: center; /* Vertically center content */
            justify-content: center; /* Horizontally center content */
            margin: 0; /* Remove default body margin */
            font-family: Arial, sans-serif; /* Set default font */
            overflow: hidden; /* Prevent scrolling */
            animation: fadeIn 1s ease-in-out; /* Fade-in animation */
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .container {
            background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2); /* Soft shadow */
            max-width: 400px; /* Limit container width */
            text-align: center; /* Center align content */
            animation: slideIn 0.5s ease-in-out; /* Slide-in animation */
        }
        @keyframes slideIn {
            from { transform: translateY(-20px); }
            to { transform: translateY(0); }
        }
        h2 {
            margin-bottom: 20px; /* Space below heading */
            color: #007bff; /* Bootstrap primary color */
            font-size: 2rem; /* Larger font size for heading */
            animation: typing 4s steps(30, end), blink-caret 0.75s step-end infinite; /* Typing and blink-caret animations */
            overflow: hidden; /* Hide overflow */
            white-space: nowrap; /* Prevent text wrap */
            border-right: 0.15em solid #007bff; /* Typing effect border */
            animation-fill-mode: forwards; /* Maintain the state at the end of the animation */
        }
        @keyframes typing {
            from { width: 0; }
            to { width: 100%; }
        }
        @keyframes blink-caret {
            from, to { border-color: transparent; }
            50% { border-color: #007bff; }
        }
        form {
            margin-top: 20px; /* Space above the form */
            animation: fadeInDelay 1.5s ease-in-out; /* Delayed fade-in animation */
        }
        @keyframes fadeInDelay {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        input[type="text"] {
            padding: 12px; /* Increased padding */
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 100%;
            max-width: 300px; /* Limit input width */
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }
        input[type="text"]:focus {
            border-color: #007bff; /* Focus color */
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25); /* Focus shadow */
        }
        input[type="text"]:hover {
            border-color: #0056b3; /* Hover color */
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5); /* Hover shadow */
        }
        .form-group {
            position: relative;
        }
        .form-group label {
            position: absolute;
            top: -8px;
            left: 12px;
            background: white;
            padding: 0 5px;
            font-size: 0.75rem;
            color: #007bff;
            transition: top 0.2s ease-in-out, left 0.2s ease-in-out, font-size 0.2s ease-in-out;
        }
        .form-group input:focus + label,
        .form-group input:not(:placeholder-shown) + label {
            top: -20px;
            left: 10px;
            font-size: 0.65rem;
            color: #0056b3;
        }
        .form-group input:not(:placeholder-shown) {
            border-color: #007bff;
        }
        .btn {
            width: 6.5em;
            height: 2.3em;
            margin: 0.5em;
            background: black;
            color: white;
            border: none;
            border-radius: 0.625em;
            font-size: 20px;
            font-weight: bold;
            cursor: pointer;
            position: relative;
            z-index: 1;
            overflow: hidden;
        }
        .btn:hover {
            color: black;
        }
        .btn:after {
            content: "";
            background: white;
            position: absolute;
            z-index: -1;
            left: -20%;
            right: -20%;
            top: 0;
            bottom: 0;
            transform: skewX(-45deg) scale(0, 1);
            transition: all 0.5s;
        }
        .btn:hover:after {
            transform: skewX(-45deg) scale(1, 1);
            -webkit-transition: all 0.5s;
            transition: all 0.5s;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Order Tracking</h2>
        <form action="order_tracking_process.php" method="POST">
            <div class="form-group">
                <input type="text" class="form-control" id="order_id" name="order_id" placeholder=" " required>
                <label for="order_id">Enter Order ID</label>
            </div>
            <button type="submit" class="btn">Track</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies (if needed) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
