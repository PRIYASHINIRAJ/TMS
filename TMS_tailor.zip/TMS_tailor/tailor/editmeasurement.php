<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}
?>

<?php
$user = $_SESSION['username'];
$usid = $pdo->query("SELECT id FROM users WHERE username='".$user."'");
$usid = $usid->fetch(PDO::FETCH_ASSOC);
$uid = $usid['id'];
include('header.php');
?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Edit Measurement</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <?php
            if ($_POST) {
                $id = $_GET["id"];
                $order_type = $_POST['order_type'];

                // Update order type
                $pdo->exec("UPDATE `customer` SET `order_type`='$order_type' WHERE `id`='$id'");

                // Update measurements
                foreach ($_POST as $key => $value) {
                    if (is_numeric($key)) {
                        $part_id = $key;
                        $measurement = $value;
                        $res = $pdo->exec("UPDATE `measurement` SET `measurement`='$measurement' WHERE `customer_id` = '$id' AND `part_id` = '$part_id'");
                    }
                }

                echo "<div class='alert alert-success alert-dismissable'>
                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                Measurements and Order Type Updated Successfully!
                </div>
                <meta http-equiv='refresh' content='2; url=orderadd.php?id=$id' />";
            }
            ?>

            <form action="editmeasurement.php?id=<?php echo ($_GET['id']); ?>" method="post">
                <div class="form-group">
                    <p style="font-weight:100; color:#666; font-size:24px;">
                        <?php
                        $id = $_GET["id"];
                        $dda = $pdo->query("SELECT fullname, sex, order_type FROM customer WHERE id = '$id'");
                        $dda = $dda->fetch(PDO::FETCH_ASSOC);
                        echo($dda['fullname']);
                        ?>
                    </p>
                </div>

                <div class="form-group">
                    <label for="order_type">Order Type:</label>
                    <select name="order_type" id="order_type" class="form-control">
                        <option value="blouse" <?php echo ($dda['order_type'] == 'blouse' ? 'selected' : ''); ?>>Blouse</option>
                        <option value="shirt" <?php echo ($dda['order_type'] == 'shirt' ? 'selected' : ''); ?>>Shirt</option>
                        <option value="gown" <?php echo ($dda['order_type'] == 'gown' ? 'selected' : ''); ?>>Gown</option>
                        <option value="other" <?php echo ($dda['order_type'] == 'other' ? 'selected' : ''); ?>>Other</option>
                    </select>
                </div>

                <?php
                $type = $pdo->query("SELECT id, title FROM type WHERE sex= '$dda[sex]'");

                while ($typee = $type->fetch(PDO::FETCH_ASSOC)) {
                    echo('<br/><br/><br/><div><p style="font-size:22px; color="#000"; font-weight="700">'.$typee['title'].'</p><br/>');
                    echo('<table>');
                    $ddaa = $pdo->query("SELECT id, title, image FROM part WHERE type='$typee[id]'");
                    while ($data = $ddaa->fetch(PDO::FETCH_ASSOC)) {
                        $mes = $pdo->query("SELECT measurement FROM measurement WHERE customer_id = '$id' AND part_id = '$data[id]'");
                        $mes = $mes->fetch(PDO::FETCH_ASSOC);
                        if (!$data['image']) $data['image'] = "tailor.png";
                        $img = 'img/part/' . $data['image'];

                        echo "<tr><td style='width:100px; height: 40px; margin: 20px;'><a href='$img'><img src='$img' width='50px' /></a></td>";
                        echo "<td style='width:200px; height: 40px; margin: 20px;'><label><a href='partedit.php?id=$data[id]'>$data[title]</a></label></td>";
                        echo "<td>
                        <select name='$data[id]' style='width:200px; height: 40px; margin: 20px;'>
                            <option value='' disabled>Select Measurement</option>";
                            for ($i = 0; $i <= 100; $i++) {
                                $selected = ($mes['measurement'] == $i) ? 'selected' : '';
                                echo "<option value='$i' $selected>$i</option>";
                            }
                        echo "</select></td></tr>";
                    }
                    echo('</table>');
                    echo('</div>');
                }
                ?>

                <input type="submit" class="btn btn-lg btn-success btn-block" value="Update">
            </form>
        </div>
    </div>
</div>

<script src="js/bootstrap-timepicker.min.js"></script>
<script>
jQuery(document).ready(function() {
    jQuery("#ssn").mask("999-99-9999");
    jQuery('#timepicker').timepicker({defaultTIme: false});
    jQuery('#timepicker2').timepicker({showMeridian: false});
    jQuery('#timepicker3').timepicker({minuteStep: 15});
});
</script>

<?php
include('footer.php');
?>
