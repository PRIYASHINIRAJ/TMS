<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

include('header.php');

// Fetch staff information
$staff_data = [
    'RC-0001' => ['name' => 'Raj', 'photo' => 'raj.jpg'],
    'RC-0002' => ['name' => 'Riya', 'photo' => 'riya.jpg']
];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Work Schedule</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to right, #ff9a9e, #fad0c4);
            margin: 0;
            padding: 0;
        }
        .container {
            padding: 20px;
            max-width: 1000px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        th, td {
            padding: 12px;
            text-align: center;
            color: #333;
        }
        th {
            background-color: #f4a261;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1c6c6;
        }
        .staff-pic {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: 3px solid #e76f51;
        }
        button {
            padding: 8px 15px;
            font-size: 14px;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button[type="submit"]:first-of-type {
            background-color: #2a9d8f;
        }
        button[type="submit"]:last-of-type {
            background-color: #e76f51;
        }
        button[type="submit"]:first-of-type:hover {
            background-color: #21867a;
        }
        button[type="submit"]:last-of-type:hover {
            background-color: #d9534f;
        }
        .form-container, .schedule-container {
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Staff Work Schedule</h1>
        
        <!-- Staff Schedule -->
        <div class="schedule-container">
            <h2>Work Schedule</h2>
            <table>
                <tr>
                    <th>Staff</th>
                    <th>Work Days</th>
                    <th>Shift</th>
                </tr>
                <tr>
                    <td>Raj (RC-0001)</td>
                    <td>Monday to Friday</td>
                    <td>10 AM to 5 PM</td>
                </tr>
                <tr>
                    <td>Riya (RC-0002)</td>
                    <td>Monday to Friday</td>
                    <td>2 PM to 9 PM</td>
                </tr>
            </table>
        </div>
        
        <!-- Staff Check-In and Check-Out Table -->
        <div class="form-container">
            <h2>Check-In/Check-Out</h2>
            <table class="staff-table">
                <tr>
                    <th>Picture</th>
                    <th>Name</th>
                    <th>Check-In</th>
                    <th>Check-Out</th>
                </tr>
                <?php foreach ($staff_data as $staff_id => $staff): ?>
                <tr>
                    <td><img src="<?php echo $staff['photo']; ?>" alt="<?php echo $staff['name']; ?>'s picture" class="staff-pic"></td>
                    <td><?php echo $staff['name']; ?></td>
                    <td>
                        <form action="checkin_process.php" method="post">
                            <input type="hidden" name="staff_id" value="<?php echo $staff_id; ?>">
                            <button type="submit">Check In</button>
                        </form>
                    </td>
                    <td>
                        <form action="checkout_process.php" method="post">
                            <input type="hidden" name="staff_id" value="<?php echo $staff_id; ?>">
                            <button type="submit">Check Out</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</body>
</html>

<?php include('footer.php'); ?>
