<?php
session_start(); // Start session (if not already started)

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection
    include('db_connection.php');

    // Function to sanitize input data
    function sanitize_input($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    // Validate and sanitize input data
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password']; // No need to hash again for comparison

    // Prepare SQL statement to retrieve user by email
    $query = "SELECT * FROM password WHERE email = ?";
    
    // Prepare and bind the statement
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("s", $email);
        
        // Execute the statement
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            
            // Check if user exists
            if ($result->num_rows == 1) {
                // Fetch user details
                $user = $result->fetch_assoc();

                // Verify password
                if (password_verify($password, $user['password'])) {
                    // Password correct, set session variables
                    $_SESSION['fullname'] = $user['fullname'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['phone'] = $user['phone'];

                    // Redirect to order tracking page or any other dashboard page
                    header('Location: order_tracking.php');
                    exit();
                } else {
                    // Password incorrect
                    display_error("Incorrect password. Please try again.");
                }
            } else {
                // User not found
                display_error("User not found. Please sign up first.");
            }
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($conn);
        }
        
        // Close the statement
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    // Close the database connection
    mysqli_close($conn);
}

function display_error($message) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="style4.css">
        <title>Login Error</title>
    </head>
    <body>
        <section class="page_404">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="col-sm-10 col-sm-offset-1 text-center">
                            <div class="four_zero_four_bg">
                                <h1 class="text-center">Error</h1>
                            </div>
                            <div class="content_box_404">
                                <h3 class="h2"><?php echo $message; ?></h3>
                                <a href="signup.php" class="btn btn-primary">Go to Home</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </body>
    </html>
    <?php
    exit();
}
?>
