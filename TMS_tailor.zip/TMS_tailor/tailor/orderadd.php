<?php
require_once('function.php'); // Include your functions file
dbconnect(); // Connect to your database
session_start(); // Start session handling

// Check if user is logged in
if (!is_user()) {
    redirect('index.php'); // Redirect to index.php if user is not logged in
}

$user = $_SESSION['username']; // Get current user's username from session
$usid = $pdo->query("SELECT id FROM users WHERE username='" . $user . "'"); // Query to get user ID
$usid = $usid->fetch(PDO::FETCH_ASSOC); // Fetch user ID from query result
$uid = $usid['id']; // Assign user ID to $uid variable
include('header.php'); // Include your header file
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Order</title>
    <link rel="stylesheet" href="css/style.default.css"> <!-- Include your CSS -->
    <style>
        /* Additional CSS styles */
        .content-wrapper {
            margin: 20px;
        }

        .form-container {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
        }

        .form-group input:focus, .form-group select:focus {
            border-color: #80bdff;
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }

        .btn-submit {
            background-color: #28a745;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-submit:hover {
            background-color: #218838;
        }

        .alert {
            padding: 15px;
            border: 1px solid transparent;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }

        .page-header {
            margin-bottom: 30px;
        }

        .page-header h1 {
            font-size: 2rem;
            color: #343a40;
        }
    </style>
</head>
<body>
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Add Order</h1>
            </div>
        </div>
        <div class="row content-wrapper">
            <div class="col-md-10 col-md-offset-1 form-container">
                <?php
                // Handle form submission
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $customer_id = $_POST["customer"]; // Get selected customer ID from form
                    $desc = $_POST["desc"]; // Get description from form
                    $date_received = $_POST["date_received"]; // Get date received from form
                    $completed = $_POST["completed"]; // Get completed status from form
                    $date_collected = $_POST["date_collected"]; // Get date collected from form
                    $amount = $_POST["amount"]; // Get amount from form
                    $paid = $_POST["paid"]; // Get paid amount from form
                    $received_by = $_POST["received_by"]; // Get received by (staff ID) from form

                    // Fetch customer's fullname based on customer ID
                    $customer_query = $pdo->prepare("SELECT fullname FROM customer WHERE id = ?");
                    $customer_query->execute([$customer_id]);
                    $customer = $customer_query->fetch(PDO::FETCH_ASSOC);
                    $customer_name = $customer['fullname'];

                    // Calculate balance
                    $balance = $amount - $paid;

                    // Insert into `order` table
                    $insert_order = $pdo->prepare("INSERT INTO `order`(`customer`, `customer_name`, `description`, `amount`, `paid`, `balance`, `received_by`, `date_received`, `completed`, `date_collected`) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

                    $insert_order->execute([$customer_id, $customer_name, $desc, $amount, $paid, $balance, $received_by, $date_received, $completed, $date_collected]);

                    // Check if insertion was successful
                    if ($insert_order) {
                        echo "<div class='alert alert-success alert-dismissable'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                            Order Added Successfully!
                        </div>";
                    }
                }
                ?>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="form-group">
                        <label>Select Customer</label>
                        <select name="customer" class="form-control">
                            <option value="0">Please Select a Customer</option>
                            <?php
                            // Fetch customers from database
                            $ddaa = $pdo->query("SELECT id, fullname FROM customer ORDER BY id");
                            while ($data = $ddaa->fetch(PDO::FETCH_ASSOC)) {
                                echo "<option value='$data[id]'>$data[fullname]</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <input type="text" name="desc" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label>Date Received</label>
                        <input type="date" name="date_received" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label>Received By</label>
                        <select name="received_by" class="form-control" required>
                            <?php
                            // Fetch staff members from database
                            $ddaa = $pdo->query("SELECT id, fullname FROM staff ORDER BY id");
                            while ($data = $ddaa->fetch(PDO::FETCH_ASSOC)) {
                                echo "<option value='$data[id]'>$data[fullname]</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Amount</label>
                        <input type="text" name="amount" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label>Paid</label>
                        <input type="text" name="paid" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label>Completed?</label>
                        <select name="completed" class="form-control" required>
                            <option value='No'>No</option>
                            <option value='Yes'>Yes</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Date to Collect</label>
                        <input type="date" name="date_collected" class="form-control" required />
                    </div>
                    <input type="submit" class="btn btn-submit" value="ADD">
                </form>
            </div>
        </div>
    </div>

    <?php include('footer.php'); ?> <!-- Include your footer file -->

    <script src="js/jquery.datatables.min.js"></script>
    <script src="js/select2.min.js"></script>
    <script src="js/bootstrap-timepicker.min.js"></script>
    <script>
        // Your JavaScript code here
    </script>
</body>
</html>
