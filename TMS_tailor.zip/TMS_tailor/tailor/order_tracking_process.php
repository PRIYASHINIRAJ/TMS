<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Tracking Result</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('background-image.jpg'); /* Replace with your background image URL */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            margin: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white overlay */
            z-index: 1;
        }
        .container {
            position: relative;
            z-index: 2;
            background-color: #ffffff; /* White container background */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2); /* Soft shadow */
            max-width: 600px;
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
            animation: bounceIn 0.6s ease-in-out;
        }
        .container:hover {
            transform: scale(1.05);
            box-shadow: 0 0 25px rgba(0,0,0,0.3);
        }
        h2 {
            color: #007bff; /* Bootstrap primary color */
            margin-bottom: 20px; /* Space below heading */
            animation: slideInDown 0.6s ease-in-out;
        }
        .order-details {
            margin-bottom: 20px;
            transition: background-color 0.3s ease-in-out;
            animation: slideIn 0.6s ease-in-out forwards;
            opacity: 0;
        }
        .order-details:nth-child(even) {
            animation-delay: 0.3s;
        }
        .order-details:hover {
            background-color: #f1f1f1;
        }
        .order-details label {
            font-weight: bold;
            display: block;
        }
        .order-details span {
            display: block;
            margin-top: 5px;
            opacity: 0;
            animation: fadeInUp 0.5s ease-in-out forwards;
        }
        .order-details.completed span {
            color: #28a745; /* Green color for completed orders */
        }
        .order-details.not-completed span {
            color: #dc3545; /* Red color for orders not completed */
        }
        .alert {
            margin-top: 20px;
            animation: fadeInUp 0.6s ease-in-out;
        }
        @keyframes bounceIn {
            from, 20%, 40%, 60%, 80%, to {
                -webkit-animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);
                animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);
            }
            from {
                opacity: 0;
                transform: scale3d(.3, .3, .3);
            }
            20% {
                transform: scale3d(1.1, 1.1, 1.1);
            }
            40% {
                transform: scale3d(.9, .9, .9);
            }
            60% {
                opacity: 1;
                transform: scale3d(1.03, 1.03, 1.03);
            }
            80% {
                transform: scale3d(.97, .97, .97);
            }
            to {
                opacity: 1;
                transform: scale3d(1, 1, 1);
            }
        }
        @keyframes slideIn {
            from {
                transform: translateX(-100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        @keyframes slideInDown {
            from {
                transform: translateY(-100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="overlay"></div>
    <div class="container">
        <h2 class="text-center">RajesCreation- Order Tracking Result</h2>

        <?php
        // Establish database connection
        $servername = "localhost";
        $username = "root"; // Replace with your MySQL username
        $password = ""; // Replace with your MySQL password
        $dbname = "tailor";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch order ID from form submission
        $order_id = $_POST['order_id'];

        // Query to fetch order details from 'order' table
        $sql = "SELECT * FROM `order` WHERE id = '$order_id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo '<div class="order-details">';
                echo '<label>Customer:</label> <span>' . $row["customer"] . '</span>';
                echo '<label>Customer Name:</label> <span>' . $row["customer_name"] . '</span>';
                echo '<label>Description:</label> <span>' . $row["description"] . '</span>';
                echo '<label>Amount:</label> <span>' . $row["amount"] . '</span>';
                echo '<label>Paid:</label> <span>' . $row["paid"] . '</span>';
                echo '<label>Balance:</label> <span>' . $row["balance"] . '</span>';
                echo '<label>Received By:</label> <span>' . $row["received_by"] . '</span>';
                echo '<label>Date Received:</label> <span>' . $row["date_received"] . '</span>';
                echo '<label>Completed:</label> <span class="' . ($row["completed"] == 1 ? 'completed' : 'not-completed') . '">' . ($row["completed"] == 1 ? 'Yes' : 'No') . '</span>';
                echo '<label>Date Collected:</label> <span>' . $row["date_collected"] . '</span>';
                echo '</div>';
            }
        } else {
            echo '<div class="alert alert-danger" role="alert">Order not found</div>';
        }

        $conn->close();
        ?>
    </div>

    <!-- Bootstrap JS and dependencies (if needed) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
