<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Check-Out Status</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('bg.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 400px;
            width: 100%;
        }
        .container h1 {
            font-size: 24px;
            color: #4CAF50;
            margin-bottom: 20px;
        }
        .message {
            margin-top: 20px;
            font-size: 18px;
            color: #333;
            padding: 15px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        .message.success {
            color: #28a745;
        }
        .message.error {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Staff Check-Out Status</h1>
        <?php
        // Enable error reporting
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

        // Database connection
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "tailor";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Set PHP timezone
        date_default_timezone_set('Asia/Kuala_Lumpur');

        // Collect data from the previous page or session (example staff_id)
        $staff_id = $_POST['staff_id'] ?? ''; // Ensure staff_id is provided from the previous page

        // Current time
        $current_time = new DateTime();
        $checkout_time = $current_time->format('Y-m-d H:i:s');
        $work_date = $current_time->format('Y-m-d');

        // Define work schedules
        $work_schedules = [
            'RC-0001' => ['start' => '10:00', 'end' => '17:00'],
            'RC-0002' => ['start' => '14:00', 'end' => '21:00']
        ];

        if (isset($work_schedules[$staff_id])) {
            $staff_schedule = $work_schedules[$staff_id];
            $start_time = new DateTime($staff_schedule['start']);
            $end_time = new DateTime($staff_schedule['end']);
            $start_time->setDate($current_time->format('Y'), $current_time->format('m'), $current_time->format('d'));
            $end_time->setDate($current_time->format('Y'), $current_time->format('m'), $current_time->format('d'));
            $start_time_str = $start_time->format('Y-m-d H:i:s');
            $end_time_str = $end_time->format('Y-m-d H:i:s');

            // Check if a record already exists for the current date
            $check_sql = "SELECT * FROM staff_in WHERE staff_id='$staff_id' AND work_date='$work_date' AND checkin_time IS NOT NULL AND checkout_time IS NULL";
            $result = $conn->query($check_sql);

            if ($result->num_rows > 0) {
                // Update check-out time
                $is_early_checkout = $checkout_time <= $end_time_str ? 1 : 0;
                $sql = "UPDATE staff_in SET checkout_time='$checkout_time', is_early_checkout=$is_early_checkout WHERE staff_id='$staff_id' AND work_date='$work_date' AND checkout_time IS NULL";

                if ($conn->query($sql) === TRUE) {
                    echo "<div class='message " . ($is_early_checkout ? "success" : "error") . "'>";
                    if ($is_early_checkout) {
                        echo "Check-out successful! <br>Current time: $checkout_time";
                    } else {
                        echo "Check-out successful but you have checked out late! <br>";
                        echo "Current time: $checkout_time <br>";
                        echo "Scheduled end time: " . $end_time->format('H:i:s') . "<br>";
                    }
                    echo "</div>";
                } else {
                    echo "<div class='message error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
                }
            } else {
                echo "<div class='message error'>No check-in record found for today. Please check in first.</div>";
            }
        } else {
            echo "<div class='message error'>Invalid staff ID.</div>";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
