<?php
// Database configuration
$host = 'localhost'; // Your host
$dbname = 'tailor'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Establish PDO connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    // Set PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
