<?php
// Include necessary PHP files and start session
require_once('function.php');
dbconnect();
session_start();

// Redirect to index.php if user is not logged in
if (!is_user()) {
    redirect('index.php');
}

// Get current user's username and ID
$user = $_SESSION['username'];
$usid = $pdo->query("SELECT id FROM users WHERE username='" . $user . "'");
$usid = $usid->fetch(PDO::FETCH_ASSOC);
$uid = $usid['id'];

// Query to get total number of customers
$customerr = $pdo->query("SELECT COUNT(*) as sum FROM customer");
$customer = $customerr->fetch(PDO::FETCH_ASSOC);

// Query to get total number of orders
$orderr = $pdo->query("SELECT COUNT(*) as sum FROM `order`");
$order = $orderr->fetch(PDO::FETCH_ASSOC);

// Query to get total income in the last 30 days
$incomee = $pdo->query("SELECT sum(amount) as sum FROM `income` WHERE date > DATE_SUB(NOW(), INTERVAL 30 DAY)");
$income = $incomee->fetch(PDO::FETCH_ASSOC);

// Query to get total expenses in the last 30 days
$expensee = $pdo->query("SELECT sum(amount) as sum FROM `expense` WHERE date > DATE_SUB(NOW(), INTERVAL 30 DAY)");
$expense = $expensee->fetch(PDO::FETCH_ASSOC);

// Include header file with styling
include('header.php');
?>

<!-- Additional CSS styles -->
<style>
    body {
        background: url('../img/bg.jpg') no-repeat center center fixed;
        background-size: cover;
        font-family: 'Roboto', sans-serif;
    }
</style>

<!-- Page content wrapper -->
<div id="page-wrapper">
    <!-- Dashboard title -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-lightblue" style="background-color: #85C1E9;">
                <div class="panel-heading">
                    <h1 class="panel-title" style="color: white;">Dashboard</h1>
                </div>
            </div>
        </div>
    </div>

    <!-- Dashboard Boxes for Customers, Orders, Income, and Expenses -->
    <div class="row">
        <!-- Customers -->
        <div class="col-lg-3 col-md-6 mb-4">
            <div class="panel panel-red">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-users fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge"><?php echo $customer['sum']; ?></div>
                            <div>Total Customers</div>
                        </div>
                    </div>
                </div>
                <a href="customerview.php">
                    <div class="panel-footer">
                        <span class="pull-left">View Details</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        <!-- Orders -->
        <div class="col-lg-3 col-md-6 mb-4">
            <div class="panel panel-purple">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-tasks fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge"><?php echo $order['sum']; ?></div>
                            <div>Total Orders</div>
                        </div>
                    </div>
                </div>
                <a href="orderlist.php">
                    <div class="panel-footer">
                        <span class="pull-left">View Details</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        <!-- Income -->
        <div class="col-lg-3 col-md-6 mb-4">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-dollar fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge"><?php echo $income['sum']; ?></div>
                            <div>Total Income (30 days)</div>
                        </div>
                    </div>
                </div>
                <a href="incview.php">
                    <div class="panel-footer">
                        <span class="pull-left">View Details</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        <!-- Expenses -->
        <div class="col-lg-3 col-md-6 mb-4">
            <div class="panel panel-yellow">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-money fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge"><?php echo $expense['sum']; ?></div>
                            <div>Total Expenses (30 days)</div>
                        </div>
                    </div>
                </div>
                <a href="expview.php">
                    <div class="panel-footer">
                        <span class="pull-left">View Details</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <!-- /.row -->

    <!-- About Us Section -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title">About Us</h3>
                </div>
                <div class="panel-body">
                    <div id="aboutCarousel" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#aboutCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#aboutCarousel" data-slide-to="1"></li>
                            <li data-target="#aboutCarousel" data-slide-to="2"></li>
                        </ol>

                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <img src="owner-pic.jpg" alt="Owner Picture" style="width: 160px; height: 180px;">
                                <div class="carousel-caption">
                                    <h3>Owner of RajesCreation</h3>
                                    <p>RAJESWARI A/P SUPPIAH</p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="row">
                                    <div class="col-xs-4">
                                        <img src="shop-pic1.jpg" alt="Shop Picture 1" style="width: 160px; height: 180px;">
                                    </div>
                                    <div class="col-xs-4">
                                        <img src="shop-pic2.jpg" alt="Shop Picture 2" style="width: 160px; height: 180px;">
                                    </div>
                                    <div class="col-xs-4">
                                        <img src="shop-pic3.jpg" alt="Shop Picture 3" style="width: 160px; height: 180px;">
                                    </div>
                                </div>
                                <div class="carousel-caption">
                                    <h2>Shop</h2>
                                </div>
                            </div>
                            <div class="item">
                                <div class="row">
                                    <div class="col-xs-4">
                                        <img src="award1.jpg" alt="Award Picture 1" style="width: 160px; height: 180px;">
                                    </div>
                                    <div class="col-xs-4">
                                        <img src="award2.jpg" alt="Award Picture 2" style="width: 160px; height: 180px;">
                                    </div>
                                    <div class="col-xs-4">
                                        <img src="award3.jpg" alt="Award Picture 3" style="width: 160px; height: 180px;">
                                    </div>
                                </div>
                                <div class="carousel-caption">
                                    <h2>Award</h2>
                                </div>
                            </div>
                        </div>

                        <!-- Controls -->
                        <a class="left carousel-control" href="#aboutCarousel" role="button" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="right carousel-control" href="#aboutCarousel" role="button" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->

    <!-- Charts Section -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Charts</h3>
            </div>
            <div class="panel-body">
                <div class="wrapper">
                    <div class="panel-body" style="width: 100%; float: left;">
                        <table class="table" width="97%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <th scope="col">Income, Expenses and Profit for past 30 days</th>
                            </tr>
                            <tr class="inner">
                                <td><canvas id="myChart" height="400px" width="800"></canvas></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <h1>Check-In/Check-Out of staffs</h1>
            <canvas id="checkinCheckoutTrend"></canvas>

            <script>
                async function fetchCheckinData() {
                    try {
                        const response = await fetch('index1.php', {
                            method: 'POST'
                        });
                        if (!response.ok) {
                            throw new Error('Network response was not ok ' + response.statusText);
                        }
                        const data = await response.json();
                        return data;
                    } catch (error) {
                        console.error('There was a problem with the fetch operation:', error);
                    }
                }

                fetchCheckinData().then(data => {
                    if (data && data.length > 0) {
                        const labels = data.map(item => item.date);
                        const checkinData = data.map(item => parseInt(item.checkin_count));
                        const checkoutData = data.map(item => parseInt(item.checkout_count));
                        const lateCheckinData = data.map(item => parseInt(item.late_checkin_count));
                        const earlyCheckoutData = data.map(item => parseInt(item.early_checkout_count));

                        var ctx = document.getElementById('checkinCheckoutTrend').getContext('2d');
                        var checkinCheckoutTrend = new Chart(ctx, {
                            type: 'line',
                            data: {
                                labels: labels,
                                datasets: [
                                    {
                                        label: 'Check-Ins',
                                        data: checkinData,
                                        borderColor: 'rgba(75, 192, 192, 1)',
                                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                        fill: true,
                                    },
                                    {
                                        label: 'Check-Outs',
                                        data: checkoutData,
                                        borderColor: 'rgba(153, 102, 255, 1)',
                                        backgroundColor: 'rgba(153, 102, 255, 0.2)',
                                        fill: true,
                                    },
                                    {
                                        label: 'Late Check-Ins',
                                        data: lateCheckinData,
                                        borderColor: 'rgba(255, 99, 132, 1)',
                                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                                        fill: true,
                                        borderDash: [5, 5], // Dotted line style for late check-ins
                                    },
                                    {
                                        label: 'Early Check-Outs',
                                        data: earlyCheckoutData,
                                        borderColor: 'rgba(255, 159, 64, 1)',
                                        backgroundColor: 'rgba(255, 159, 64, 0.2)',
                                        fill: true,
                                        borderDash: [5, 5], // Dotted line style for late check-outs
                                    }
                                ]
                            },
                            options: {
                                scales: {
                                    x: {
                                        beginAtZero: true,
                                        title: {
                                            display: true,
                                            text: 'Date'
                                        }
                                    },
                                    y: {
                                        beginAtZero: true,
                                        title: {
                                            display: true,
                                            text: 'Count'
                                        }
                                    }
                                },
                                plugins: {
                                    legend: {
                                        display: true,
                                        position: 'top',
                                    },
                                    tooltip: {
                                        callbacks: {
                                            label: function (tooltipItem) {
                                                return tooltipItem.dataset.label + ': ' + tooltipItem.raw;
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    } else {
                        console.log("No data available");
                    }
                });
            </script>

<div id="chart-container">
<h1>Materials checking</h1>
        <canvas id="materialPieChart"></canvas>
    </div>

    <script>
        // Fetch the data for the pie chart
        fetch('material.php')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                // Debugging statements
                console.log("Fetched Data: ", data);

                const productNames = data.productNames;
                const quantities = data.quantities;

                // Check if data is not empty
                if (productNames.length > 0 && quantities.length > 0) {
                    // Create the pie chart
                    const ctx = document.getElementById('materialPieChart').getContext('2d');
                    const materialPieChart = new Chart(ctx, {
                        type: 'pie',
                        data: {
                            labels: productNames,
                            datasets: [{
                                label: 'Material Availability',
                                data: quantities,
                                backgroundColor: [
                                    '#FF6384', // Coral Red
                                    '#36A2EB', // Sky Blue
                                    '#FFCE56', // Gold
                                    '#4BC0C0', // Turquoise
                                    '#9966FF', // Lavender
                                    '#FF9F40', // Orange
                                    '#FF5722', // Deep Orange
                                    '#9C27B0', // Purple
                                    '#E91E63', // Pink
                                    '#3F51B5'  // Indigo
                                ],
                                borderColor: [
                                    '#FF6384', 
                                    '#36A2EB', 
                                    '#FFCE56', 
                                    '#4BC0C0', 
                                    '#9966FF', 
                                    '#FF9F40', 
                                    '#FF5722', 
                                    '#9C27B0', 
                                    '#E91E63', 
                                    '#3F51B5'
                                ],
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    position: 'top',
                                },
                                title: {
                                    display: true,
                                    text: 'Material Availability'
                                }
                            }
                        }
                    });
                } else {
                    console.error("No data available to display the chart");
                }
            })
            .catch(error => console.error('There was a problem with the fetch operation:', error));
    </script>
            </div>
        </div>
    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->

<?php
// Function to calculate income for a given date
function income($today, $pdo) {
    $sites = $pdo->query("SELECT sum(amount) as sum FROM `income` WHERE date LIKE '%$today%'");
    $sites = $sites->fetch(PDO::FETCH_ASSOC);
    $sites2 = $pdo->query("SELECT sum(amount) as sum FROM `order` WHERE date_received LIKE '%$today%'");
    $sites2 = $sites2->fetch(PDO::FETCH_ASSOC);
    $site1 = $sites['sum'] + $sites2['sum'];
    return $site1;
}

// Function to calculate expenses for a given date
function expenses($today, $pdo) {
    $sites = $pdo->query("SELECT sum(amount) as sum FROM `expense` WHERE date LIKE '%$today%'");
    $sites = $sites->fetch(PDO::FETCH_ASSOC);
    return $sites['sum'];
}

// Function to calculate profit for a given date
function profit($today, $pdo) {
    $sites = $pdo->query("SELECT sum(amount) as sum FROM `income` WHERE date LIKE '%$today%'");
    $sites = $sites->fetch(PDO::FETCH_ASSOC);
    $sites2 = $pdo->query("SELECT sum(amount) as sum FROM `order` WHERE date_received LIKE '%$today%'");
    $sites2 = $sites2->fetch(PDO::FETCH_ASSOC);
    $site1 = $sites['sum'] + $sites2['sum'];
    $sites2 = $pdo->query("SELECT sum(amount) as sum FROM `expense` WHERE date LIKE '%$today%'");
    $sites2 = $sites2->fetch(PDO::FETCH_ASSOC);
    $site = $site1 - $sites2['sum'];
    if($site < 0) $site = 0;
    return $site;
}

// Fetch data for last 30 days
$dates = array();
$incomes = array();
$expenses = array();
$profits = array();

for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime('-' . $i . ' days'));
    $dates[] = $date;
    $incomes[] = income($date, $pdo);
    $expenses[] = expenses($date, $pdo);
    $profits[] = profit($date, $pdo);
}

// JavaScript section to initialize Chart.js with PHP data
?>

<!-- Additional JavaScript for Chart.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.bundle.min.js"></script>
<script>
    // PHP variables to JavaScript arrays
    var dates = <?php echo json_encode($dates); ?>;
    var incomeData = <?php echo json_encode($incomes); ?>;
    var expenseData = <?php echo json_encode($expenses); ?>;
    var profitData = <?php echo json_encode($profits); ?>;

    // Bar chart data
    var barChartData = {
        labels: dates,
        datasets: [{
            label: 'Income',
            backgroundColor: "rgba(13, 162, 30, 0.5)",
            strokeColor: "rgba(13, 162, 30, 0.8)",
            highlightFill: "rgba(13, 162, 30, 0.75)",
            highlightStroke: "rgba(13, 162, 30, 1)",
            data: incomeData
        }, {
            label: 'Expenses',
            backgroundColor: "rgba(255, 193, 7, 0.5)",
            strokeColor: "rgba(255, 193, 7, 0.8)",
            highlightFill: "rgba(255, 193, 7, 0.75)",
            highlightStroke: "rgba(255, 193, 7, 1)",
            data: expenseData
        }, {
            label: 'Profit',
            backgroundColor: "rgba(13, 31, 162, 0.5)",
            strokeColor: "rgba(13, 31, 162, 0.8)",
            highlightFill: "rgba(13, 31, 162, 0.75)",
            highlightStroke: "rgba(13, 31, 162, 1)",
            data: profitData
        }]
    };

    // Render bar chart
    window.onload = function () {
        var ctx = document.getElementById("myChart").getContext("2d");
        window.myBar = new Chart(ctx, {
            type: 'bar',
            data: barChartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    xAxes: [{
                        stacked: true,
                        gridLines: {
                            display: false
                        }
                    }],
                    yAxes: [{
                        stacked: true,
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    };
</script>

<?php
// Include footer file
include('footer.php');
?>
