-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2024 at 12:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tailor`
--

-- --------------------------------------------------------

--
-- Table structure for table `calendar`
--

CREATE TABLE `calendar` (
  `id` int(11) NOT NULL,
  `order` int(8) NOT NULL,
  `title` varchar(160) NOT NULL,
  `description` text NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `allDay` varchar(5) NOT NULL,
  `color` varchar(7) NOT NULL,
  `url` varchar(255) NOT NULL,
  `category` varchar(200) NOT NULL,
  `repeat_type` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `repeat_id` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'todo'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `calendar`
--

INSERT INTO `calendar` (`id`, `order`, `title`, `description`, `start`, `end`, `allDay`, `color`, `url`, `category`, `repeat_type`, `user_id`, `repeat_id`, `status`) VALUES
(1, 0, 'Priya Dress', 'Need to buy fabric', '2024-05-24 00:00:00', '2024-05-24 00:00:00', 'true', '#587ca3', 'false', '', '', 0, 0, 'todo'),
(2, 0, 'Priashini: Dress', 'Dress', '2024-05-21 00:00:00', '2024-05-25 00:00:00', 'true', '#a00000', '../orderedit.php?id=1', 'Orders', '', 1, 0, 'todo'),
(3, 0, 'Gown', 'Gown for Kumuda', '2024-07-03 00:00:00', '2024-07-03 00:00:00', 'true', '#587ca3', 'false', '', '', 0, 0, 'todo'),
(4, 0, 'Kumuda Gown', 'Deliver gown', '2024-07-01 13:38:00', '2024-07-03 13:38:00', 'true', '#3d00ff', 'false', '', '', 0, 0, 'todo'),
(5, 0, 'Kumuda: Gown', 'Gown', '2024-06-20 00:00:00', '2024-07-05 00:00:00', 'true', '#00a014', '../orderedit.php?id=2', 'Orders', '', 1, 0, 'todo'),
(6, 0, 'Niemal: Trouser', 'Trouser', '2024-06-26 00:00:00', '2024-07-06 00:00:00', 'true', '#00a014', '../orderedit.php?id=3', 'Orders', '', 1, 0, 'todo'),
(7, 0, 'Priya: Blouse', 'Blouse', '2024-07-10 00:00:00', '2024-07-14 00:00:00', 'true', '#a00000', '../orderedit.php?id=4', 'Orders', '', 1, 0, 'todo'),
(8, 0, 'Priya blouse', '', '2024-07-09 20:34:00', '2024-07-15 20:34:00', 'true', '', 'false', '', '', 0, 0, 'todo'),
(9, 0, 'Priya Blouse', 'Blouse', '2024-07-15 19:30:00', '2024-07-15 20:00:00', 'true', '#587ca3', 'false', '', '', 0, 0, 'todo'),
(10, 0, 'Shivaani: long skirt', 'long skirt', '2024-07-14 00:00:00', '2024-07-21 00:00:00', 'true', '#a00000', '../orderedit.php?id=5', 'Orders', '', 1, 0, 'todo'),
(11, 0, 'Shivaani: long skirt', 'long skirt', '2024-07-14 00:00:00', '2024-07-21 00:00:00', 'true', '#a00000', '../orderedit.php?id=6', 'Orders', '', 1, 0, 'todo'),
(12, 0, 'Shivaani: long skirt', 'long skirt', '2024-07-14 00:00:00', '2024-07-21 00:00:00', 'true', '#a00000', '../orderedit.php?id=7', 'Orders', '', 1, 0, 'todo'),
(13, 0, 'Shivaani long skirt', '', '2024-07-15 00:00:00', '2024-07-15 00:00:00', 'true', '#587ca3', 'false', '', '', 0, 0, 'todo'),
(14, 0, 'Niemal: Gown', 'Gown', '2024-07-15 00:00:00', '2024-07-24 00:00:00', 'true', '#a00000', '../orderedit.php?id=8', 'Orders', '', 1, 0, 'todo'),
(15, 0, 'kumu blouse', '', '2024-07-15 17:48:00', '2024-07-25 17:48:00', 'true', '', 'false', '', '', 0, 0, 'todo'),
(16, 0, 'Kiven Raj: Trouser', 'Trouser', '2024-07-17 00:00:00', '2024-07-25 00:00:00', 'true', '#a00000', '../orderedit.php?id=9', 'Orders', '', 1, 0, 'todo'),
(17, 0, 'Nathan Raj: Trouser', 'Trouser', '2024-07-15 00:00:00', '2024-07-31 00:00:00', 'true', '#a00000', '../orderedit.php?id=10', 'Orders', '', 1, 0, 'todo'),
(18, 0, 'priya', 'dress', '2024-07-01 00:00:00', '2024-07-01 00:00:00', 'true', '#587ca3', 'false', '', '', 0, 0, 'todo'),
(19, 0, 'Priashini: dress', 'dress', '2024-07-18 00:00:00', '2024-07-31 00:00:00', 'true', '#00a014', '../orderedit.php?id=11', 'Orders', '', 1, 0, 'todo'),
(20, 0, 'Rathna Kumaran: shirt', 'shirt', '2024-07-16 00:00:00', '2024-08-06 00:00:00', 'true', '#00a014', '../orderedit.php?id=12', 'Orders', '', 1, 0, 'todo'),
(21, 0, 'Priya: dress', 'dress', '2024-07-16 00:00:00', '2024-07-16 00:00:00', 'true', '#00a014', '../orderedit.php?id=13', 'Orders', '', 1, 0, 'todo');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `sex` tinyint(2) NOT NULL,
  `email` varchar(100) NOT NULL,
  `comment` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `status` enum('TODO','Doing','Done') DEFAULT 'TODO',
  `password` varchar(255) NOT NULL,
  `order_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `fullname`, `phonenumber`, `address`, `sex`, `email`, `comment`, `city`, `status`, `password`, `order_type`) VALUES
(3, 'Kumuda', '0125678893', 'Garing Permai', 1, 'Kumuda@gmail.com', 'Stitch Gown', 'Rawang', 'TODO', '', NULL),
(4, 'Niemal', '0164140141', 'Penang', 0, 'niemal@gmail.com', '', 'Penang', 'TODO', '', NULL),
(5, 'Priya', '0126773524', 'Rawang', 1, 'priya@gmail.com', 'Blouse', 'Rawang', 'TODO', '', NULL),
(6, 'Shivaani', '1234567890', 'Teluk Intan', 1, 'shivaani@gmail.com', 'Stitch a long skirt', 'Teluk Intan', 'TODO', '', NULL),
(8, 'Kiven Raj', '01162261472', 'Taman Garing Permai', 0, 'kiven2004@gmail.com', 'Trousers', 'Rawang', 'TODO', '', NULL),
(9, 'Nathan Raj', '0122121635', 'Taman Garing Jaya', 0, 'nathanrajsho@gmail.com', 'Trousers', 'Rawang', 'TODO', '', NULL),
(10, 'Niemal', '0184626491', '', 0, '', '', '', 'TODO', '', NULL),
(11, 'Rathna Kumaran', '01114454281', 'ipoh', 0, 'rathna190@gmail.com', 'Shirt', 'perak', 'TODO', '', NULL),
(14, 'Setha Letchumy', '01111811963', 'No 19, Jalan 4, Taman Garing Jaya, 48000 Rawang, Sekangor.', 1, 'setha1894@gmail.com', 'Blouse', 'Rawang', 'TODO', '', NULL),
(15, 'priyashini raj', '0126773524', 'No 17, Jalan 4, Taman Sri Rawang, 48000 Rawang, Selangor', 1, 'priyashiniraj15@gmail.com', 'Gown', 'Rawang', 'TODO', '', 'gown');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `detail` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `title`, `detail`, `img`) VALUES
(2, 'Cover ', 'Rajes Creation', '1719812217.jpg'),
(3, 'Cover ', 'Rajes Creation', '1719812231.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE `email` (
  `id` int(8) NOT NULL,
  `customer` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`id`, `customer`, `message`, `date`) VALUES
(1, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-05-21'),
(2, 'Priyashini Raj', 'Dear Priyashini Raj,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-05-21'),
(3, 'Priyashini Raj', 'Dear Priyashini Raj,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-05-21'),
(4, 'Priyashini Raj', 'Dear Priyashini Raj,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-05-21'),
(5, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-06-25'),
(6, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-06-25'),
(7, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-06-27'),
(8, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-01'),
(9, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-01'),
(10, 'sathya', 'Dear sathya,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-01'),
(11, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-01'),
(12, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-11'),
(13, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-11'),
(14, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(15, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(16, 'Nathan Raj', 'Dear Nathan Raj,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(17, 'Nathan Raj', 'Dear Nathan Raj,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(18, 'Nathan Raj', 'hi', '2024-07-15'),
(19, 'Nathan Raj', 'hi', '2024-07-15'),
(20, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-16'),
(21, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-16'),
(22, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-16'),
(23, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-16');

-- --------------------------------------------------------

--
-- Table structure for table `expcat`
--

CREATE TABLE `expcat` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `expcat`
--

INSERT INTO `expcat` (`id`, `title`) VALUES
(1, 'Material Purchase'),
(2, 'Staff Salary'),
(3, 'Rent'),
(4, 'Staff Incentive'),
(5, 'Machine Purchase'),
(6, 'Machine Maintenance and Repair'),
(7, 'Electricity'),
(8, 'Generator Fuel'),
(9, 'Generator Maintenance'),
(10, 'Tax, Dues, Security, Waste'),
(11, 'Needle, Tread, Accessory Purchase');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `id` int(11) NOT NULL,
  `expcat` int(8) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `amount` int(8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`id`, `expcat`, `description`, `date`, `amount`) VALUES
(3, 2, 'Staff', '2024-07-01', 100),
(4, 6, 'sewing machine repair', '2024-07-09', 150),
(2, 1, 'Scissors', '2024-05-16', 38),
(5, 2, 'Nathan Raj Salary', '2024-07-03', 300),
(6, 2, 'Raj Salary', '2024-07-10', 2500),
(7, 10, '', '2024-07-17', 180),
(8, 11, 'Accessory', '2024-07-19', 128);

-- --------------------------------------------------------

--
-- Table structure for table `general_setting`
--

CREATE TABLE `general_setting` (
  `id` int(11) NOT NULL,
  `sitename` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `currency` varchar(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sms` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `general_setting`
--

INSERT INTO `general_setting` (`id`, `sitename`, `email`, `mobile`, `currency`, `sms`) VALUES
(1, 'Rajes Creation', 'rajescreation@gmail.com', '0126773524', 'RM', '');

-- --------------------------------------------------------

--
-- Table structure for table `inccat`
--

CREATE TABLE `inccat` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `inccat`
--

INSERT INTO `inccat` (`id`, `title`) VALUES
(1, 'Sew  New Cloth'),
(2, 'Repair Cloth'),
(4, 'Training and Tutor'),
(5, 'Machine Repair'),
(6, 'Mass Production');

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE `income` (
  `id` int(11) NOT NULL,
  `inccat` int(8) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `amount` int(8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `income`
--

INSERT INTO `income` (`id`, `inccat`, `description`, `date`, `amount`) VALUES
(1, 1, 'Gown', '2024-07-03', 75),
(2, 1, 'dress', '2024-07-01', 55),
(3, 1, 'Niemal Trousers', '2024-06-26', 160),
(4, 4, 'Tailoring class at Seremban for 3 students', '2024-06-15', 300),
(5, 6, '', '2024-07-10', 1000),
(6, 1, 'Payment for Order: 1', '2024-07-01', 20),
(7, 1, 'Payment for Order: 2', '2024-07-01', 45),
(8, 1, 'Payment for Order: 11', '2024-07-16', 1000),
(9, 4, 'SJK (T) BUKIT NENAS', '2024-07-09', 2500),
(10, 1, 'Payment for Order: 1', '2024-07-20', 1),
(11, 1, 'Payment for Order: 7', '2024-07-23', 28),
(12, 1, 'Payment for Order: 16', '2024-07-23', 50),
(13, 1, 'Payment for Order: 8', '2024-07-23', 20),
(14, 1, 'Payment for Order: 9', '2024-07-23', 22),
(15, 1, 'Payment for Order: 7', '2024-07-23', 10),
(16, 1, 'Payment for Order: 4', '2024-07-23', 0),
(17, 1, 'Payment for Order: 7', '2024-07-23', 12),
(18, 1, 'Payment for Order: 7', '2024-07-23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `availability` varchar(10) NOT NULL,
  `quantity` int(11) NOT NULL,
  `picture_url` varchar(255) NOT NULL,
  `date_added` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `product_name`, `availability`, `quantity`, `picture_url`, `date_added`) VALUES
(8, 'Fabric A (Silk)', 'Available', 38, 'img/fabric_a.jpg', '2024-07-18 12:29:11'),
(9, 'Fabric B (Cotton)', 'Not Availa', 29, 'img/fabric_b.jpg', '2024-07-23 17:19:22'),
(10, 'Thread ', 'Available', 50, 'img/thread_c.jpg', '2024-07-23 17:19:12'),
(11, 'Button', 'Available', 40, 'img/button_d.jpg', '2024-07-23 17:19:32'),
(12, 'Zipper ', 'Not Availa', 37, 'img/zipper_e.jpg', '2024-07-19 19:51:08'),
(13, 'Lining ', 'Available', 30, 'img/lining_f.jpg', '2024-07-18 12:41:22'),
(14, 'Needle ', 'Available', 40, 'img/needle_g.jpg', '2024-07-19 19:50:59');

-- --------------------------------------------------------

--
-- Table structure for table `measurement`
--

CREATE TABLE `measurement` (
  `measurement_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `part_id` int(8) NOT NULL,
  `measurement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `measurement`
--

INSERT INTO `measurement` (`measurement_id`, `customer_id`, `part_id`, `measurement`) VALUES
(1, 2, 4, ''),
(2, 2, 5, ''),
(3, 2, 6, ''),
(4, 2, 7, ''),
(5, 2, 8, ''),
(6, 2, 9, ''),
(7, 2, 10, ''),
(8, 2, 11, ''),
(9, 2, 12, ''),
(10, 2, 13, ''),
(11, 2, 64, ''),
(12, 2, 65, ''),
(13, 2, 22, ''),
(14, 2, 23, ''),
(15, 2, 24, ''),
(16, 2, 25, ''),
(17, 2, 26, ''),
(18, 2, 27, ''),
(19, 2, 28, ''),
(20, 2, 29, ''),
(21, 2, 30, ''),
(22, 2, 31, ''),
(23, 2, 32, ''),
(24, 2, 33, ''),
(25, 2, 34, ''),
(26, 2, 35, ''),
(27, 2, 36, ''),
(28, 2, 37, ''),
(29, 2, 46, ''),
(30, 2, 67, ''),
(31, 2, 55, ''),
(32, 2, 56, ''),
(33, 2, 57, ''),
(34, 2, 59, ''),
(35, 2, 58, ''),
(36, 2, 60, ''),
(37, 2, 61, ''),
(38, 2, 62, ''),
(39, 3, 4, '0'),
(40, 3, 5, '0'),
(41, 3, 6, '0'),
(42, 3, 7, '0'),
(43, 3, 8, '0'),
(44, 3, 9, '0'),
(45, 3, 10, '0'),
(46, 3, 11, '0'),
(47, 3, 12, '0'),
(48, 3, 13, '0'),
(49, 3, 64, '0'),
(50, 3, 65, '0'),
(51, 3, 22, '0'),
(52, 3, 23, '0'),
(53, 3, 24, '0'),
(54, 3, 25, '0'),
(55, 3, 26, '0'),
(56, 3, 27, '0'),
(57, 3, 28, '0'),
(58, 3, 29, '0'),
(59, 3, 30, '0'),
(60, 3, 31, '0'),
(61, 3, 32, '0'),
(62, 3, 33, '0'),
(63, 3, 34, '0'),
(64, 3, 35, '0'),
(65, 3, 36, '0'),
(66, 3, 37, '0'),
(67, 3, 46, '0'),
(68, 3, 67, ''),
(69, 3, 55, '0'),
(70, 3, 56, '0'),
(71, 3, 57, '0'),
(72, 3, 59, '0'),
(73, 3, 58, '29'),
(74, 3, 60, '27'),
(75, 3, 61, '25'),
(76, 3, 62, '25'),
(77, 1, 4, ''),
(78, 1, 5, ''),
(79, 1, 6, ''),
(80, 1, 7, ''),
(81, 1, 8, ''),
(82, 1, 9, ''),
(83, 1, 10, ''),
(84, 1, 11, ''),
(85, 1, 12, ''),
(86, 1, 13, ''),
(87, 1, 64, ''),
(88, 1, 65, ''),
(89, 1, 22, ''),
(90, 1, 23, ''),
(91, 1, 24, ''),
(92, 1, 25, ''),
(93, 1, 26, ''),
(94, 1, 27, ''),
(95, 1, 28, ''),
(96, 1, 29, ''),
(97, 1, 30, ''),
(98, 1, 31, ''),
(99, 1, 32, ''),
(100, 1, 33, ''),
(101, 1, 34, ''),
(102, 1, 35, ''),
(103, 1, 36, ''),
(104, 1, 37, ''),
(105, 1, 46, ''),
(106, 1, 67, ''),
(107, 1, 55, '26'),
(108, 1, 56, '30'),
(109, 1, 57, '21'),
(110, 1, 59, '25'),
(111, 1, 58, ''),
(112, 1, 60, ''),
(113, 1, 61, ''),
(114, 1, 62, '87'),
(115, 4, 14, '30'),
(116, 4, 15, '33'),
(117, 4, 16, '21'),
(118, 4, 17, '17'),
(119, 4, 18, '38'),
(120, 4, 19, '19'),
(121, 4, 20, '18'),
(122, 4, 21, '24'),
(123, 4, 38, ''),
(124, 4, 39, ''),
(125, 4, 40, ''),
(126, 4, 41, ''),
(127, 4, 42, ''),
(128, 4, 43, ''),
(129, 4, 44, ''),
(130, 4, 45, ''),
(131, 4, 47, ''),
(132, 4, 48, ''),
(133, 4, 49, ''),
(134, 4, 50, ''),
(135, 4, 51, ''),
(136, 4, 52, ''),
(137, 4, 53, ''),
(138, 4, 54, ''),
(139, 4, 66, ''),
(140, 5, 4, ''),
(141, 5, 5, ''),
(142, 5, 6, ''),
(143, 5, 7, ''),
(144, 5, 8, ''),
(145, 5, 9, ''),
(146, 5, 10, ''),
(147, 5, 11, ''),
(148, 5, 12, ''),
(149, 5, 13, ''),
(150, 5, 64, ''),
(151, 5, 65, ''),
(152, 5, 22, '26'),
(153, 5, 23, '35'),
(154, 5, 24, '12'),
(155, 5, 25, '34'),
(156, 5, 26, '25'),
(157, 5, 27, '25'),
(158, 5, 28, '27'),
(159, 5, 29, ''),
(160, 5, 30, ''),
(161, 5, 31, '27'),
(162, 5, 32, '28'),
(163, 5, 33, '27'),
(164, 5, 34, '27'),
(165, 5, 35, '28'),
(166, 5, 36, '14'),
(167, 5, 37, '17'),
(168, 5, 46, '17'),
(169, 5, 55, ''),
(170, 5, 56, ''),
(171, 5, 57, ''),
(172, 5, 59, ''),
(173, 5, 58, ''),
(174, 5, 60, ''),
(175, 5, 61, ''),
(176, 5, 62, ''),
(177, 6, 4, ''),
(178, 6, 5, ''),
(179, 6, 6, ''),
(180, 6, 7, ''),
(181, 6, 8, ''),
(182, 6, 9, ''),
(183, 6, 10, ''),
(184, 6, 11, ''),
(185, 6, 12, ''),
(186, 6, 13, ''),
(187, 6, 64, ''),
(188, 6, 65, ''),
(189, 6, 22, ''),
(190, 6, 23, ''),
(191, 6, 24, ''),
(192, 6, 25, ''),
(193, 6, 26, ''),
(194, 6, 27, ''),
(195, 6, 28, ''),
(196, 6, 29, ''),
(197, 6, 30, ''),
(198, 6, 31, ''),
(199, 6, 32, ''),
(200, 6, 33, ''),
(201, 6, 34, ''),
(202, 6, 35, ''),
(203, 6, 36, ''),
(204, 6, 37, ''),
(205, 6, 46, ''),
(206, 6, 55, '27'),
(207, 6, 56, '29'),
(208, 6, 57, '31'),
(209, 6, 59, '15'),
(210, 6, 58, ''),
(211, 6, 60, ''),
(212, 6, 61, ''),
(213, 6, 62, ''),
(214, 7, 4, ''),
(215, 7, 5, ''),
(216, 7, 6, ''),
(217, 7, 7, ''),
(218, 7, 8, ''),
(219, 7, 9, ''),
(220, 7, 10, ''),
(221, 7, 11, ''),
(222, 7, 12, ''),
(223, 7, 13, ''),
(224, 7, 64, ''),
(225, 7, 65, ''),
(226, 7, 22, ''),
(227, 7, 23, ''),
(228, 7, 24, ''),
(229, 7, 25, ''),
(230, 7, 26, ''),
(231, 7, 27, ''),
(232, 7, 28, ''),
(233, 7, 29, ''),
(234, 7, 30, ''),
(235, 7, 31, ''),
(236, 7, 32, ''),
(237, 7, 33, ''),
(238, 7, 34, ''),
(239, 7, 35, ''),
(240, 7, 36, ''),
(241, 7, 37, ''),
(242, 7, 46, ''),
(243, 7, 55, '34'),
(244, 7, 56, '39'),
(245, 7, 57, '39'),
(246, 7, 59, '17'),
(247, 7, 58, ''),
(248, 7, 60, ''),
(249, 7, 61, ''),
(250, 7, 62, ''),
(251, 8, 14, '20'),
(252, 8, 15, '21'),
(253, 8, 16, '14'),
(254, 8, 17, '10'),
(255, 8, 18, '30'),
(256, 8, 19, '12'),
(257, 8, 20, '22'),
(258, 8, 21, '22'),
(259, 8, 38, ''),
(260, 8, 39, ''),
(261, 8, 40, ''),
(262, 8, 41, ''),
(263, 8, 42, ''),
(264, 8, 43, ''),
(265, 8, 44, ''),
(266, 8, 45, ''),
(267, 8, 47, ''),
(268, 8, 48, ''),
(269, 8, 49, ''),
(270, 8, 50, ''),
(271, 8, 51, ''),
(272, 8, 52, ''),
(273, 8, 53, ''),
(274, 8, 54, ''),
(275, 9, 14, '29'),
(276, 9, 15, '27'),
(277, 9, 16, '13'),
(278, 9, 17, '20'),
(279, 9, 18, '30'),
(280, 9, 19, '19'),
(281, 9, 20, '10'),
(282, 9, 21, '16'),
(283, 9, 38, ''),
(284, 9, 39, ''),
(285, 9, 40, ''),
(286, 9, 41, ''),
(287, 9, 42, ''),
(288, 9, 43, ''),
(289, 9, 44, ''),
(290, 9, 45, ''),
(291, 9, 47, ''),
(292, 9, 48, ''),
(293, 9, 49, ''),
(294, 9, 50, ''),
(295, 9, 51, ''),
(296, 9, 52, ''),
(297, 9, 53, ''),
(298, 9, 54, ''),
(299, 11, 14, ''),
(300, 11, 15, ''),
(301, 11, 16, ''),
(302, 11, 17, ''),
(303, 11, 18, ''),
(304, 11, 19, ''),
(305, 11, 20, ''),
(306, 11, 21, ''),
(307, 11, 38, '12'),
(308, 11, 39, '23'),
(309, 11, 40, '29'),
(310, 11, 41, '30'),
(311, 11, 42, '31'),
(312, 11, 43, '19'),
(313, 11, 44, ''),
(314, 11, 45, ''),
(315, 11, 47, ''),
(316, 11, 48, ''),
(317, 11, 49, ''),
(318, 11, 50, ''),
(319, 11, 51, ''),
(320, 11, 52, ''),
(321, 11, 53, ''),
(322, 11, 54, ''),
(323, 15, 4, '0'),
(324, 15, 5, '0'),
(325, 15, 6, '0'),
(326, 15, 7, '0'),
(327, 15, 8, '0'),
(328, 15, 9, '0'),
(329, 15, 10, '0'),
(330, 15, 11, '0'),
(331, 15, 12, '0'),
(332, 15, 13, '0'),
(333, 15, 64, '0'),
(334, 15, 65, '0'),
(335, 15, 22, '0'),
(336, 15, 23, '0'),
(337, 15, 24, '0'),
(338, 15, 25, '0'),
(339, 15, 26, '0'),
(340, 15, 27, '0'),
(341, 15, 28, '0'),
(342, 15, 29, '0'),
(343, 15, 30, '0'),
(344, 15, 31, '0'),
(345, 15, 32, '0'),
(346, 15, 33, '0'),
(347, 15, 34, '0'),
(348, 15, 35, '0'),
(349, 15, 36, '0'),
(350, 15, 37, '0'),
(351, 15, 46, '0'),
(352, 15, 55, '0'),
(353, 15, 56, '0'),
(354, 15, 57, '0'),
(355, 15, 59, '0'),
(356, 15, 58, '29'),
(357, 15, 60, '26'),
(358, 15, 61, '25'),
(359, 15, 62, '22');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(8) NOT NULL,
  `customer` int(8) NOT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `paid` decimal(11,2) NOT NULL,
  `balance` decimal(11,2) NOT NULL,
  `received_by` int(11) NOT NULL,
  `date_received` date DEFAULT NULL,
  `completed` varchar(10) DEFAULT 'No',
  `date_collected` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `customer`, `customer_name`, `description`, `amount`, `paid`, `balance`, `received_by`, `date_received`, `completed`, `date_collected`) VALUES
(2, 3, 'Kumuda', 'Gown', 75.00, 75.00, 0.00, 1, '2024-06-20', 'Yes', '2024-07-05'),
(3, 4, 'Niemal', 'Trouser', 160.00, 160.00, 0.00, 1, '2024-06-26', 'Yes', '2024-07-06'),
(4, 5, 'Priya', 'Blouse', 100.00, 50.10, 49.90, 1, '2024-07-10', 'Yes', '2024-07-14'),
(7, 6, 'Shivaani', 'long skirt', 90.00, 90.00, 0.00, 1, '2024-07-14', 'No', '2024-07-21'),
(8, 4, 'Niemal', 'Gown', 187.00, 120.00, 67.00, 1, '2024-07-15', 'No', '2024-07-24'),
(9, 8, 'Kiven Raj', 'Trouser', 88.00, 72.40, 15.60, 1, '2024-07-17', 'No', '2024-07-25'),
(10, 9, NULL, 'Trouser', 100.00, 76.00, 0.00, 1, '2024-07-15', 'No', '2024-07-31'),
(11, 1, NULL, 'dress', 1000.00, 2000.00, 0.00, 1, '2024-07-18', 'Yes', '2024-07-31'),
(12, 11, NULL, 'shirt', 150.00, 100.00, 0.00, 1, '2024-07-16', 'Yes', '2024-08-06'),
(13, 5, NULL, 'dress', 12.00, 12.00, 0.00, 1, '2024-07-16', 'Yes', '2024-07-16'),
(14, 10, 'Vijaya', 'Trouser', 100.00, 76.00, 24.00, 1, '2024-07-18', 'No', '2024-07-25'),
(15, 15, 'priyashini raj', 'Gown', 148.00, 100.00, 48.00, 1, '2024-07-21', 'No', '2024-07-31'),
(16, 14, 'Setha Letchumy', 'Blouse', 145.00, 130.23, 65.00, 1, '2024-07-23', 'No', '2024-07-26'),
(17, 15, 'priyashini raj', 'Blouse', 100.00, 30.00, 70.00, 1, '2024-07-23', 'No', '2024-07-30');

-- --------------------------------------------------------

--
-- Table structure for table `part`
--

CREATE TABLE `part` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `part`
--

INSERT INTO `part` (`id`, `title`, `type`, `description`, `image`) VALUES
(3, 'NECK', 7, '  Place two fingers between the tape measure and the neck as the pictures show, and make sure you can move the tape easily. Do not tighten the tape measure. Make sure that the tape is at the base of the neck where the neck and shoulders meet or at the height where the collar would be if you were wearing a shirt.', 'neck.jpg'),
(4, 'CHEST', 1, ' Stand up straight, relax and take deep breath with hands down at your side. The chest measurement should be taken around the chest under the armpits. Make sure the tape is parallel and you can move the tape easily. Do not tighten the tape measure. Avoid having thick clothes on when measuring.', 'chest.jpg'),
(5, 'WAIST', 1, ' Stand up in a relaxed posture, do not hold your breath or hold your stomach in. If you do not have beer belly, the waist measurement should be taken around the waist at the narrowest point. If you have beer belly, you should measure the widest point. Make sure you can move the tape easily. Do not tighten the tape measure.', 'waist.jpg'),
(6, 'HIPS', 1, ' Take out all of the stuff in the front and back pockets your trouser. The hip measurement should be taken around the hips at the widest point. Stand up in a relaxed posture, and keep the tape parallel. Do not tighten the tape measure. Make sure you can move the tape easily. ', 'hips.jpg'),
(7, 'SHOULDER', 1, ' Stand up in a relaxed posture. Measure across the top of the shoulder from one edge to the other. Ensure you take the curved contour over the top of the shoulders as shown. If you are wearing your best fitted shirt measure up to the shoulder seams', 'shoulder.jpg'),
(8, 'SLEEVE LENGTH', 1, ' The sleeve measurement should be taken from exactly the same point you used earlier for the \"Shoulder\" measurement. Measure from tip of shoulder to a point at the wrist where you want the sleeve to end. Do not bend your arms. If you want to match your dress shirt with a suit, you should measure the suit sleeve length you want, and then add one (1) centimeter .That will be the shirt\'s sleeve length.\n', 'sleeve-length.jpg'),
(9, 'SHORT SLEEVE LENGTH ', 1, ' Measure with arm at your side, from the tip of the shoulder to a point on the outside of the arm where you want the sleeve to end. ', 'short-sleeve-length.jpg'),
(10, 'WRIST/CUFF ', 1, ' Measure the actual wrist size around your wrist bone. You may also consider adding Â¼\" to Â½\" to your size if you wear medium to heavier watches. ', 'wrist-cuff.jpg'),
(11, 'BICEP ', 1, ' widest point. This is normally taken about 15cm to 18 cm from the tip of the shoulder seam. This is the sleeve width of the largest part of your arm. **Do not flex your bicep.** ', 'biceps.jpg'),
(12, 'SHIRT LENGTH ', 1, ' Stand up in a relaxed posture. Measure from the topmost point of the shoulder at a point near the nape at the collar seam, along the front of your body, to a point where you want the shirt to end. ', 'shirt-length.jpg'),
(13, ' ARMHOLE ', 1, ' Place the tape measure under your armpit and around the top of your arm. To ensure a comfortable fit, take the armhole measurement with one finger inside the tape measure. ', 'arm-hole.jpg'),
(14, 'WAIST', 3, ' Wearing trousers and a shirt put the measuring tape around your waist at the height were you would wear your pants and adjust to your designed snugness with room for a finger. Make sure the tape is snug and does not ride over the waistband but you should be able to put your index finger inside the tape.  ', 'touser-waist.jpg'),
(15, 'HIPS ', 3, ' Wearing trousers, measure around the fullest part of your hips, placing a finger between your body and the tape. Make sure the tape is straight at all times. Make sure your pockets are empty and the tape is not restrictive. As a guide, you should not make the tape too snug. You only just need to be able to feel the tape when measuring.', 'touser-hip.jpg'),
(16, 'CROTCH', 3, ' Measure from the top middle of the back pants waist (see point A) all along the crotch seam through your legs until the top of front waist (see point B)', 'touser-crotch.jpg'),
(17, 'THIGH WIDTH ', 3, ' Wearing trousers, empty your pockets then, start at the top of your inseam, measure around your thigh with room for a finger.', 'touser-thigh-width..jpg'),
(18, 'TROUSER LENGTH', 3, ' Measure from the top of pants waist all along the side pant seam until the bottom of your pants or roughly 1 inch from the ground', 'touser-length.jpg'),
(19, ' INSEAM ', 3, ' Measure from the lowest part of your crotch area to the floor.  Make sure the tape is tight along the inside of your leg, that you are standing straight, and then measure.  No shoes please! ', 'touser-inseam.jpg'),
(20, ' KNEE ', 3, ' Measure around your knee at its widest point.  You need only measure one knee', 'touser-knee.jpg'),
(21, 'HALF HEM ', 3, ' Measure the width you want for the bottom of your trousers. ', 'touser-crotch-half-hem.jpg'),
(22, 'SHIRT LENGTH ', 2, ' Take the measure from the highest part of your shoulder (next to the collar) to the longest part of the shirt. See image on the left. ', 'shirt-length.jpg'),
(23, 'SHOULDER WIDTH ', 2, ' Measure the distance from one shoulder to the other, the measuring tape has to start and finish one centimeter before the end of your shoulder. See picture on the left. ', 'shoulder-width.jpg'),
(24, 'NECK', 2, ' Measure around your neck. Adjust the measuring tape to your preferred looseness. It is very important to introduce a finger between your body and the tape. ', 'neck.jpg'),
(25, 'CHEST', 2, ' Measure around the widest part of your chest (put the measuring tape on both nipples). Let loose so that you can put a finger between your body and the tape. Make sure that the tape is at an even height all the way around. ', 'chest.jpg'),
(26, ' BICEP ', 2, ' Measure around the widest part of your bicep. Let loose so that you can put a finger between your body and the tape. ', 'bicep.jpg'),
(27, 'WRIST', 2, ' Measure around the wrist leaving one finger of space to take the measurement. ', 'wrist.jpg'),
(28, 'SLEEVE', 2, ' ', 'sleeve.jpg'),
(29, 'SHORT SLEEVE ', 2, ' ', 'short-sleeve.jpg'),
(30, 'Â¾ SLEEVE ', 2, ' ', '3-4-sleeve.jpg'),
(31, 'WAIST', 2, ' ', 'waist.jpg'),
(32, 'STOMACH ', 2, ' ', 'stomach.jpg'),
(33, ' HIPS ', 2, ' ', 'hips.jpg'),
(34, ' BREAST POINT ', 2, ' Measure from the highest point of your shoulder, to the breast point (the most outstanding part of your breast). ', 'breast.jpg'),
(35, 'WAIST POINT ', 2, ' ', 'waist-point.jpg'),
(36, 'SLEEVE HOLE ', 2, ' ', 'sleeve-hole.jpg'),
(37, 'BUST', 2, ' ', 'bust.jpg'),
(38, 'NECK', 6, ' ', 'neck.jpg'),
(39, 'CHEST', 6, ' ', 'chest.jpg'),
(40, 'STOMACH ', 6, ' ', 'stomach.jpg'),
(41, 'WAIST', 6, ' ', 'waist.jpg'),
(42, 'HIPS', 6, ' ', 'hips.jpg'),
(43, 'SHOULDER', 6, ' ', 'shoulder.jpg'),
(44, 'JACKET LENGTH', 6, ' ', 'jacket-lenght.jpg'),
(45, 'SLEEVE LENGTH', 6, ' ', 'sleeve-length.jpg'),
(46, 'BICEP ', 2, ' ', 'biceps.jpg'),
(47, 'WRIST', 6, ' ', 'wrist.jpg'),
(48, ' VEST LENGTH ', 6, ' ', 'vest-lenght.jpg'),
(49, 'CROTCH', 6, ' ', 'crotch.jpg'),
(50, 'THIGH WIDTH ', 6, ' ', 'thigh-width.jpg'),
(51, 'TROUSER LENGTH', 6, ' ', 'pant-length.jpg'),
(52, 'INSEAM', 6, ' ', 'inseam.jpg'),
(53, 'KNEE', 6, ' ', 'knee.jpg'),
(54, 'HALF HEM ', 6, ' ', 'half-hem.jpg'),
(55, 'WAIST', 4, '  ', 'skirtwaist.png'),
(56, 'WAIST TO HIP HEIGHT', 4, '   ', 'skirthip1.png'),
(57, 'LENGHT', 4, 'Women  Skirt Lenght', 'skirtlenght.png'),
(58, 'HALLOW TO HEM', 5, 'HALLOW TO HEM', 'gown.jpg'),
(59, 'HIP WIDTH', 4, '  ', 'skirthip2.png'),
(60, 'BURST', 5, ' ', 'gown.jpg'),
(61, 'WAIST', 5, ' ', 'gown.jpg'),
(62, 'HIP', 5, ' ', 'gown.jpg'),
(63, 'Hcig', 14, ' ', ''),
(64, '', 1, ' ', ''),
(65, 'Water', 1, ' jk.;l', '');

-- --------------------------------------------------------

--
-- Table structure for table `password`
--

CREATE TABLE `password` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password`
--

INSERT INTO `password` (`id`, `fullname`, `email`, `phone`, `password`) VALUES
(1, 'priyashini raj', 'priyashiniraj15@gmail.com', '0126772534', '$2y$10$Q8MYGxLyJ06STR5E7GVxe.REYP.K07DAjYO8cNs2TX7lMVfsDL6Xm'),
(2, 'priyashini raj', 'priyashiniraj15@gmail.com', '0126772534', '$2y$10$rqL88SpNN0U0LiB9oYcazOkBbyjrWvGjtjjLMgBn3L95vjJoQcWve'),
(3, 'priyashini raj', 'priyashiniraj15@gmail.com', '0126772534', '$2y$10$LbGiYoc6tnluoLxdRZGezOJ8JGht9h0vKeTS.imDvK73JkMD5BrX.'),
(4, 'priyashini raj', 'priyashiniraj15@gmail.com', '0126772534', '$2y$10$gBg1AlivNntgVWmdpc9PquviJ.ve3/DinU0YCgdvLfg2dyqAMIHtK'),
(5, 'priyashini raj', 'priyashiniraj15@gmail.com', '0126772534', '$2y$10$iXLpSGzZuTrROXmi83SfY.gnU3Guorb4GEqFG42PDqPDpYZPY4xFK'),
(6, 'priyashini raj', 'priyashiniraj15@gmail.com', '0126772534', '$2y$10$PU18luGU1JLmmFEj1/06euRZeMcPuWrNRP2AHRCVgeGZ8qTyDxXMy'),
(7, 'priyashini raj', 'priyashiniraj15@gmail.com', '0126772534', '$2y$10$gQa7w82Mdzutm0LBjBKerORIDnXN3Qv6qnW5bySIi3hTBLm1U4IoW'),
(8, 'priyashini raj', 'priyashiniraj15@gmail.com', '0126772534', '$2y$10$jsENoEK6QOZv5kax9HewVuf1I6D6Qp1eDJK9YVhVF6G7v5F2iFYVq'),
(9, '', '', '', '$2y$10$CVe8B93ILlxMfFSrrxNLx.cr37absD8/gjVrHEjQyQinC.0LhREea'),
(10, 'priyashini raj', 'priyashiniraj15@gmail.com', '0126772534', '$2y$10$aGNI3/kn.312rnZahz4Q7uUycl300hA44EIauezvCPt0M7ZM81bN6'),
(11, '', 'priyashiniraj15@gmail.com', '', '$2y$10$/0aWvwCaukQVsyE0uCWv..QUsulGYlap4.9MNMc1/CE.QRcyRDnoG'),
(12, '', 'm-3574148@moe-dl.edu.my', '', '$2y$10$SGYzzIZpSZ4fdya1bbUfsujnaKn9njN/zExeh4sRsu7HF8tTD249K'),
(13, 'Vijaya', 'vijayanathanraj@gmail.com', '0126773505', '$2y$10$NlrhcnTBkfQk14o3fJ4We.hlLEbpBj847g6CmcGAqqiZx9YhQoDVe'),
(14, 'Niemal', 'niemal@gmail.com', '0184626491', '$2y$10$o91d9RHEoCb8gO3.ddO2peIbe5QHfEJ59I/Mt8C/Lo.zJkQ8pZtoe'),
(15, 'priyashini raj', 'priyashiniraj15@gmail.com', '0126772534', '$2y$10$cywLrOVM6zWH9la7fV2pb.yQN7MMNkHK3u1uT0nKHjVNdQmqKZv9C'),
(16, 'Priyashini Raj', 'priyashiniraj15@gmail.com', '0126773524', '$2y$10$LPxfmnBbKGI7dhMMUl2lIumcTR6ZU.NKljAr7bQMFXvXH3px3/6YG');

-- --------------------------------------------------------

--
-- Table structure for table `sms`
--

CREATE TABLE `sms` (
  `id` int(8) NOT NULL,
  `customer` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `sms`
--

INSERT INTO `sms` (`id`, `customer`, `message`, `date`) VALUES
(1, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-05-21'),
(2, 'Priyashini Raj', 'Dear Priyashini Raj,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-05-21'),
(3, 'Priyashini Raj', 'Dear Priyashini Raj,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-05-21'),
(4, 'Vijaya', 'Dear Vijaya,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-05-21'),
(5, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-06-25'),
(6, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-06-27'),
(7, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-01'),
(8, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-10'),
(9, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-11'),
(10, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-11'),
(11, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-11'),
(12, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-12'),
(13, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(14, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(15, 'priyashini', 'Dear priyashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(16, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(17, 'Kumuda', 'Dear+Kumuda%2C%0D%0AYour+Clothes+are+ready+for+collection.+Thanks+for+your+patronage', '2024-07-15'),
(18, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(19, 'Kumuda', 'Dear Kumuda,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(20, 'priyashini', 'please collect your clothes', '2024-07-15'),
(21, 'priyashini', 'collect your clothes', '2024-07-15'),
(22, 'Priashini', 'Dear Priashini,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(23, 'Niemal', 'Dear Niemal,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(24, 'Niemal', 'Dear Niemal,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(25, 'Kumuda', 'Dear Kumuda,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(26, 'priyashini', 'hi', '2024-07-15'),
(27, 'Kiven Raj', 'Dear Kiven Raj,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(28, 'Kiven Raj', 'Dear Kiven Raj,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(29, 'Nathan Raj', 'Dear Nathan Raj,\r\nYour Clothes are ready for collection. Thanks for your patronage', '2024-07-15'),
(30, 'priyashini', 'Hi', '2024-07-15'),
(31, 'priyashini', 'Hi', '2024-07-15'),
(32, 'vijaya', 'Hi', '2024-07-15'),
(33, 'vijaya', 'Hi', '2024-07-15');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(8) NOT NULL,
  `stafftype` int(8) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phonenumber` varchar(50) NOT NULL,
  `salary` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `stafftype`, `fullname`, `address`, `phonenumber`, `salary`) VALUES
(1, 4, 'Raj', 'Melacca', '0126773505', 2500),
(2, 2, 'Riya', 'Melacca', '0122121635', 300);

-- --------------------------------------------------------

--
-- Table structure for table `stafftype`
--

CREATE TABLE `stafftype` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `stafftype`
--

INSERT INTO `stafftype` (`id`, `title`) VALUES
(1, 'Tailor'),
(2, 'Counter'),
(3, 'Security'),
(4, 'Manager');

-- --------------------------------------------------------

--
-- Table structure for table `staff_in`
--

CREATE TABLE `staff_in` (
  `id` int(11) NOT NULL,
  `staff_id` varchar(10) NOT NULL,
  `checkin_time` datetime DEFAULT NULL,
  `checkout_time` datetime DEFAULT NULL,
  `work_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `is_late_checkin` tinyint(4) DEFAULT 0,
  `is_early_checkout` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_in`
--

INSERT INTO `staff_in` (`id`, `staff_id`, `checkin_time`, `checkout_time`, `work_date`, `start_time`, `end_time`, `is_late_checkin`, `is_early_checkout`) VALUES
(1, 'RC-0001', '2024-07-22 22:42:33', '2024-07-22 22:42:42', '2024-07-22', '10:00:00', NULL, 1, 0),
(2, 'RC-0002', '2024-07-22 22:42:37', '2024-07-22 22:42:55', '2024-07-22', '14:00:00', NULL, 1, 0),
(3, 'RC-0001', '2024-07-22 22:43:36', '2024-07-22 22:47:39', '2024-07-22', '10:00:00', NULL, 1, 0),
(4, 'RC-0002', '2024-07-22 22:48:09', '2024-07-22 22:48:14', '2024-07-22', '14:00:00', NULL, 1, 0),
(5, 'RC-0002', '2024-07-22 22:50:17', '2024-07-22 22:50:21', '2024-07-22', '14:00:00', NULL, 1, 0),
(6, 'RC-0001', '2024-07-23 08:07:50', '2024-07-23 08:11:21', '2024-07-23', '10:00:00', NULL, 0, 1),
(7, 'RC-0002', '2024-07-23 08:15:18', '2024-07-23 16:29:10', '2024-07-23', '14:00:00', NULL, 0, 1),
(8, 'RC-0001', '2024-07-23 13:08:18', '2024-07-23 13:08:25', '2024-07-23', '10:00:00', NULL, 1, 1),
(9, 'RC-0001', '2024-07-23 16:29:13', '2024-07-23 16:29:17', '2024-07-23', '10:00:00', NULL, 1, 1),
(10, 'RC-0001', '2024-07-23 16:33:15', '2024-07-23 16:33:19', '2024-07-23', '10:00:00', NULL, 1, 1),
(11, 'RC-0002', '2024-07-23 16:34:09', NULL, '2024-07-23', '14:00:00', NULL, 1, 0),
(12, 'RC-0001', '2024-07-23 16:39:09', '2024-07-23 16:39:12', '2024-07-23', '10:00:00', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `template`
--

CREATE TABLE `template` (
  `id` int(8) NOT NULL,
  `title` varchar(255) NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `template`
--

INSERT INTO `template` (`id`, `title`, `msg`) VALUES
(1, 'Collect Your Clothes', 'Thank you for choosing RajesCreation. Your order has been finished and is ready for collection. Please collect it as soon as possible.');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id` int(8) NOT NULL,
  `title` varchar(50) NOT NULL,
  `sex` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id`, `title`, `sex`) VALUES
(1, 'SHIRT', 1),
(2, 'BLOUSE', 1),
(3, 'TROUSER', 0),
(4, 'SKIRT', 1),
(5, 'GOWN', 1),
(6, 'SUIT', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', '827ccb0eea8a706c4c34a16891f84e7b'),
(2, 'testuser', '8cb2237d0679ca88db6464eac60da96345513964');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `calendar`
--
ALTER TABLE `calendar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email`
--
ALTER TABLE `email`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expcat`
--
ALTER TABLE `expcat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `general_setting`
--
ALTER TABLE `general_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inccat`
--
ALTER TABLE `inccat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `income`
--
ALTER TABLE `income`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `measurement`
--
ALTER TABLE `measurement`
  ADD PRIMARY KEY (`measurement_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `part`
--
ALTER TABLE `part`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password`
--
ALTER TABLE `password`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sms`
--
ALTER TABLE `sms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stafftype`
--
ALTER TABLE `stafftype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_in`
--
ALTER TABLE `staff_in`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `template`
--
ALTER TABLE `template`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `calendar`
--
ALTER TABLE `calendar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `email`
--
ALTER TABLE `email`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `expcat`
--
ALTER TABLE `expcat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `general_setting`
--
ALTER TABLE `general_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inccat`
--
ALTER TABLE `inccat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `income`
--
ALTER TABLE `income`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `measurement`
--
ALTER TABLE `measurement`
  MODIFY `measurement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=360;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `part`
--
ALTER TABLE `part`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `password`
--
ALTER TABLE `password`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `sms`
--
ALTER TABLE `sms`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stafftype`
--
ALTER TABLE `stafftype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `staff_in`
--
ALTER TABLE `staff_in`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `template`
--
ALTER TABLE `template`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
