<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tailor";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect data from form
$staff_id = $_POST['staff_id'];
$work_date = $_POST['work_date'];
$start_time = $_POST['start_time'];
$end_time = $_POST['end_time'];

// Insert data into database
$sql = "INSERT INTO staff_in (staff_id, work_date, start_time, end_time) VALUES ('$staff_id', '$work_date', '$start_time', '$end_time')";

if ($conn->query($sql) === TRUE) {
    echo "Schedule updated successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
