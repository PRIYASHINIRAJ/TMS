<?php
session_start();
if (!isset($_SESSION['customer_id'])) {
    header('Location: index.php');
    exit();
}

// Database connection
include('db_connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_id = $_POST['customer_id'];

    $query = "SELECT * FROM `order` WHERE customer_id = '$customer_id'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        while ($order = mysqli_fetch_assoc($result)) {
            echo "Description: " . $order['description'] . "<br>";
            echo "Completed: " . ($order['completed'] ? "Yes" : "No") . "<br>";
            echo "Date to Receive: " . $order['date_to_receive'] . "<br>";
        }
    } else {
        echo "No orders found for this ID.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Page</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Customer Information</h2>
        <form method="post">
            <div class="form-group">
                <label for="customer_id">Customer ID</label>
                <input type="text" name="customer_id" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Get Order Info</button>
        </form>
    </div>
</body>
</html>
