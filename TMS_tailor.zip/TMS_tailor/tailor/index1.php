<?php
// Handle PHP for fetching data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "tailor";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query to count check-ins, check-outs, late check-ins, and late check-outs per day
    $sql = "
        SELECT 
            DATE(checkin_time) as date, 
            COUNT(CASE WHEN checkin_time IS NOT NULL THEN id END) as checkin_count,
            COUNT(CASE WHEN checkout_time IS NOT NULL THEN id END) as checkout_count,
            COUNT(CASE WHEN is_late_checkin = 1 THEN id END) as late_checkin_count,
            COUNT(CASE WHEN is_early_checkout = 1 THEN id END) as early_checkout_count
        FROM staff_in
        GROUP BY DATE(checkin_time)
        ORDER BY DATE(checkin_time)
    ";

    $result = $conn->query($sql);

    if ($result === FALSE) {
        die("Error: " . $conn->error);
    }

    $data = array();
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode($data);

    $conn->close();
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check-In/Check-Out Trends</title>
    <style>
        #checkinCheckoutTrend {
            width: 100%;
            height: 400px;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <h1>Check-In/Check-Out Trends</h1>
    <canvas id="checkinCheckoutTrend"></canvas>
    
    <script>
        async function fetchData() {
            try {
                const response = await fetch('index1.php', {
                    method: 'POST'
                });
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                const data = await response.json();
                return data;
            } catch (error) {
                console.error('There was a problem with the fetch operation:', error);
            }
        }

        fetchData().then(data => {
            if (data && data.length > 0) {
                const labels = data.map(item => item.date);
                const checkinData = data.map(item => parseInt(item.checkin_count));
                const checkoutData = data.map(item => parseInt(item.checkout_count));
                const lateCheckinData = data.map(item => parseInt(item.late_checkin_count));
                const earlyCheckoutData = data.map(item => parseInt(item.early_checkout_count));

                var ctx = document.getElementById('checkinCheckoutTrend').getContext('2d');
                var checkinCheckoutTrend = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [
                            {
                                label: 'Check-Ins',
                                data: checkinData,
                                borderColor: 'rgba(75, 192, 192, 1)',
                                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                fill: true,
                            },
                            {
                                label: 'Check-Outs',
                                data: checkoutData,
                                borderColor: 'rgba(153, 102, 255, 1)',
                                backgroundColor: 'rgba(153, 102, 255, 0.2)',
                                fill: true,
                            },
                            {
                                label: 'Late Check-Ins',
                                data: lateCheckinData,
                                borderColor: 'rgba(255, 99, 132, 1)',
                                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                                fill: true,
                                borderDash: [5, 5], // Dotted line style for late check-ins
                            },
                            {
                                label: 'Late Check-Outs',
                                data: earlyCheckoutData,
                                borderColor: 'rgba(255, 159, 64, 1)',
                                backgroundColor: 'rgba(255, 159, 64, 0.2)',
                                fill: true,
                                borderDash: [5, 5], // Dotted line style for late check-outs
                            }
                        ]
                    },
                    options: {
                        scales: {
                            x: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Date'
                                }
                            },
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Count'
                                }
                            }
                        },
                        plugins: {
                            legend: {
                                display: true,
                                position: 'top',
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(tooltipItem) {
                                        return tooltipItem.dataset.label + ': ' + tooltipItem.raw;
                                    }
                                }
                            }
                        }
                    }
                });
            } else {
                console.log("No data available");
            }
        });
    </script>
</body>
</html>
