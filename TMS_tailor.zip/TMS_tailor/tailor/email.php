<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

include('header.php');

$user = $_SESSION['username'];
$usid = $pdo->query("SELECT id FROM users WHERE username='".$user."'");
$usid = $usid->fetch(PDO::FETCH_ASSOC);
$uid = $usid['id'];
?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Send EMAIL</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <form action="" method="get" enctype="text/plain" id="emailForm">
                <div class="form-group">
                    <label>Select Customer</label>
                    <select name="to" id='customer' class="form-control">
                        <option value="">Please Select a Customer</option>
                        <?php
                        $customers = $pdo->query("SELECT id, fullname, email FROM customer ORDER BY id");
                        while ($data = $customers->fetch(PDO::FETCH_ASSOC)) {
                            echo "<option value='{$data['email']}' data-name='{$data['fullname']}'>{$data['fullname']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Select a Template</label>
                    <select name="template" id='template' class="form-control">
                        <option value="0">Please Select a Template</option>
                        <?php
                        $templates = $pdo->query("SELECT id, title, msg FROM template ORDER BY id");
                        while ($data = $templates->fetch(PDO::FETCH_ASSOC)) {
                            echo "<option value='{$data['title']}' data-message='{$data['msg']}'>{$data['title']}</option>";
                        }
                        ?>
                    </select>
                </div>
                
                <input type="submit" class="btn btn-lg btn-success btn-block" value="SEND">
            </form>
        </div>
    </div>
</div>

<script>
    // Update subject and body based on selected template and customer
    document.getElementById("emailForm").onsubmit = function() {
        var customerEmail = document.getElementById("customer").value;
        var templateTitle = document.getElementById("template").value;
        var templateMessage = document.getElementById("template").options[document.getElementById("template").selectedIndex].getAttribute('data-message');
        var customerName = document.getElementById("customer").options[document.getElementById("customer").selectedIndex].getAttribute('data-name');
        
        var subject = encodeURIComponent(templateTitle);
        var body = encodeURIComponent(`Dear ${customerName},\n\n${templateMessage}`);
        
        var mailtoLink = "mailto:" + customerEmail + "?subject=" + subject + "&body=" + body;
        window.location.href = mailtoLink;
        
        return false; // Prevent form submission
    };
</script>

<?php
include('footer.php');
?>
