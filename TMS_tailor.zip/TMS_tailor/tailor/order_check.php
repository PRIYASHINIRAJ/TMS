<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

include('header.php');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tailor";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Update order status to completed
if (isset($_GET['complete_id'])) {
    $complete_id = $_GET['complete_id'];
    $update_query = "UPDATE `order` SET completed='Yes' WHERE id=$complete_id";
    if ($conn->query($update_query) === TRUE) {
        echo "<script>alert('Order marked as completed.'); window.location.href='order_check.php';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Fetch orders due in the next 2 days
$query = "SELECT id, customer_name, description, date_received, date_collected, completed FROM `order` ORDER BY date_collected ASC";
$result = mysqli_query($conn, $query);

// Fetch counts for completed and uncompleted orders
$completed_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM `order` WHERE completed='Yes'"))['count'];
$uncompleted_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM `order` WHERE completed!='Yes'"))['count'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Orders and Due Dates</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .warning {
            background-color: #ffcccb;
        }
        .near-due {
            background-color: #fff7cc;
        }
        .completed {
            background-color: #d4edda;
        }
        .actions a {
            margin-right: 10px;
            text-decoration: none;
            color: #007BFF;
        }
        .actions a:hover {
            text-decoration: underline;
        }
        .chart-container {
            background: #fff;
            padding: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            width: 150px; /* Set width for small size */
            height: 150px; /* Set height for small size */
        }
        .chart-container canvas {
            width: 100% !important;
            height: 100% !important;
        }
    </style>
</head>
<body>
<body>
    <div class="container">
        <div class="page-title">
            Order Status
        </div>
        <div class="chart-container">
            <canvas id="ordersChart"></canvas>
        </div>
        <h1>Customer Orders and Due Dates</h1>
        <p>Manage and track orders efficiently</p>
        
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Description</th>
                    <th>Date Received</th>
                    <th>Date Collected</th>
                    <th>Completed</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <?php
                        $due_date = strtotime($row['date_collected']);
                        $current_date = time();
                        $date_diff = ($due_date - $current_date) / (60 * 60 * 24);
                    ?>
                    <tr class="<?= $row['completed'] == 'Yes' ? 'completed' : ($date_diff <= 2 ? 'warning' : ($date_diff <= 5 ? 'near-due' : '')); ?>">
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['customer_name'] ?></td>
                        <td><?= $row['description'] ?></td>
                        <td><?= $row['date_received'] ?></td>
                        <td><?= $row['date_collected'] ?></td>
                        <td><?= $row['completed'] ?></td>
                        <td class="actions">
                            <a href="customerview.php?id=<?= $row['id'] ?>">View</a>
                            <?php if ($row['completed'] !== 'Yes'): ?>
                                <a href="order_check.php?complete_id=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to mark this order as completed?');">Mark as Completed</a>
                            <?php else: ?>
                                <span>Completed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        var ctx = document.getElementById('ordersChart').getContext('2d');
        var ordersChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Completed Orders', 'Uncompleted Orders'],
                datasets: [{
                    label: 'Orders',
                    data: [<?= $completed_count ?>, <?= $uncompleted_count ?>],
                    backgroundColor: ['#28a745', '#dc3545'],
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                }
            },
        });
    </script>
</body>
</html>

<?php
// Close database connection
mysqli_close($conn);
?>
<?php include('footer.php'); ?>