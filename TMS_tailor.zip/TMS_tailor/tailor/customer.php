<?php
session_start();
if (!isset($_SESSION['customer_id'])) {
    header('Location: index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection
    include('db_connection.php');

    $customer_id = $_POST['customer_id'];

    $query = "SELECT c.id, o.order_details, o.completed, o.receive_date
              FROM customer c
              JOIN `order` o ON c.id = o.customer_id
              WHERE c.id = '$customer_id'";

    $result = mysqli_query($conn, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        $error = "No orders found for this ID.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Orders</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>View Orders</h2>
        <form method="post">
            <div class="form-group">
                <label for="customer_id">Customer ID</label>
                <input type="text" name="customer_id" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">View Orders</button>
        </form>
        <?php if (isset($row)): ?>
            <h3>Order Details</h3>
            <p>ID: <?php echo $row['id']; ?></p>
            <p>Order Details: <?php echo $row['order_details']; ?></p>
            <p>Completed: <?php echo $row['completed'] ? 'Yes' : 'No'; ?></p>
            <p>Receive Date: <?php echo $row['receive_date']; ?></p>
        <?php elseif (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
