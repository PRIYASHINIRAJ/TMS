<?php
// Establish database connection
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "tailor";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch order ID from form submission
$order_id = $_POST['order_id'];

// Query to fetch order details from 'order' table
$sql = "SELECT * FROM `order` WHERE id = '$order_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Customer: " . $row["customer"]. "<br>";
        echo "Description: " . $row["description"]. "<br>";
        echo "Amount: " . $row["amount"]. "<br>";
        echo "Paid: " . $row["paid"]. "<br>";
        echo "Balance: " . $row["balance"]. "<br>";
        echo "Received By: " . $row["received_by"]. "<br>";
        echo "Date Received: " . $row["date_received"]. "<br>";
        echo "Completed: " . ($row["completed"] == 1 ? 'Yes' : 'No') . "<br>";
        echo "Date Collected: " . $row["date_collected"]. "<br>";
    }
} else {
    echo "Order not found";
}

$conn->close();
?>
