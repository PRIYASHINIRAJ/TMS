<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Tracking</title>
    <!-- Include Bootstrap CSS or your preferred styling -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Add custom styles here if needed */
    </style>
</head>
<body>
    <div class="container">
        <h2>Order Tracking</h2>
        <form action="order_tracking_process.php" method="POST">
            <div class="form-group">
                <label for="order_id">Enter Order ID:</label>
                <input type="text" class="form-control" id="order_id" name="order_id" required>
            </div>
            <button type="submit" class="btn btn-primary">Track Order</button>
        </form>

        <!-- Display order tracking results here if needed -->
    </div>
</body>
</html>
