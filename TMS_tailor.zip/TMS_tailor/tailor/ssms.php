<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

if ($_POST) {
    $customer = $_POST["customer"];
    $phone = $_POST["phone"];

    // Add country code if missing and remove leading zero
    $country_code = "+60"; // Change this to your country code
    $phone_with_code = $country_code . ltrim($phone, '0');

    // Construct WhatsApp message
    $whatsapp_message = "Dear $customer, your order has been processed. Thank you for choosing us!";

    // URL encode the message
    $encoded_message = urlencode($whatsapp_message);

    // Construct WhatsApp URL with phone number and message
    $whatsapp_url = "https://api.whatsapp.com/send?phone=" . urlencode($phone_with_code) . "&text=" . $encoded_message;

    // Redirect to WhatsApp
    echo "<script>window.location.href = '$whatsapp_url';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send SMS</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS for styling -->
    <style>
        .form-container {
            background-color: #ffffff; /* White background */
            padding: 20px; /* Padding inside the container */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 0 10px rgba(0,0,0,0.1); /* Drop shadow for depth */
        }
    </style>
</head>
<body>

<?php include ('header.php'); ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="form-container">
                <h1 class="text-center mb-4">Send SMS</h1>
                <form action="ssms.php" method="post">
                    <div class="form-group">
                        <label for="customer">Name of Recipient</label>
                        <input type="text" name="customer" id="customer" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="text" name="phone" id="phone" class="form-control" value="0xxxxxxxxx" required>
                        <small class="form-text text-muted">Enter phone number without country code (e.g., 0123456789)</small>
                    </div>

                    <button type="submit" class="btn btn-success btn-block">Open WhatsApp</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include ('footer.php'); ?>

<!-- Include Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
