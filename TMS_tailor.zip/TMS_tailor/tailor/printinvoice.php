<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

$user = $_SESSION['username'];
$usid = $pdo->query("SELECT id FROM users WHERE username='".$user."'");
$usid = $usid->fetch(PDO::FETCH_ASSOC);
$uid = $usid['id'];
include ('header.php');
?>

<style type="text/css" media="print">
    @page {
        size: auto;
        margin: 0mm;
    }

    body {
        background-color: #FFFFFF;
        margin: 0px;
        padding: 20px;
    }

    b,
    strong {
        font-weight: 100 !important;
    }
</style>

<script>
    function printContent(el) {
        var restorepage = document.body.innerHTML;
        var printcontent = document.getElementById(el).innerHTML;
        document.body.innerHTML = printcontent;
        window.print();
        document.body.innerHTML = restorepage;
    }
</script>

<div class="pageheader">
    <h2><i class="fa fa-th-list"></i> Print Receipt</h2>
</div>

<div class="contentpanel">

    <div id="ass" class="col-md-8 col-md-offset-2" style="border-style: solid; border-color: #bbb; background-color: #fff; padding: 20px;">
        
        <?php

        $id = $_GET["id"];

        $order = $pdo->query("SELECT * FROM `order` WHERE id='".$id."'");
        $order = $order->fetch(PDO::FETCH_ASSOC);

        $customer = $pdo->query("SELECT fullname, phonenumber, address, email FROM customer WHERE id='".$order['customer']."'");
        $customer = $customer->fetch(PDO::FETCH_ASSOC);

        $staff = $pdo->query("SELECT fullname FROM staff WHERE id='".$order['received_by']."'");
        $staff = $staff->fetch(PDO::FETCH_ASSOC);

        $total_amount = $order['amount']; // Total amount
        $amount_paid = $order['paid'];     // Amount paid
        $balance = $order['balance'];      // Balance
        ?>

        <div style="border-bottom: 2px solid #000; margin-bottom: 20px;"></div>

        <div class="row">
            <div class="col-md-12 text-center">
                <h3 style="margin-bottom: 20px;">Invoice</h3>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <p><strong>Order ID:</strong> <?php echo $order['id']; ?></p>
                <p><strong>Customer:</strong> <?php echo $customer['fullname']; ?></p>
                <p><strong>Address:</strong> <?php echo $customer['address']; ?></p>
                <p><strong>Phone:</strong> <?php echo $customer['phonenumber']; ?></p>
                <p><strong>Email:</strong> <?php echo $customer['email']; ?></p>
            </div>
            <div class="col-md-6 text-right">
                <p><strong>Date Received:</strong> <?php echo $order['date_collected']; ?></p>
                <p><strong>Served By:</strong> <?php echo $staff['fullname']; ?></p>
            </div>
        </div>

        <div style="border-top: 2px solid #000; margin-top: 20px; margin-bottom: 20px;"></div>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $order['description']; ?></td>
                        <td><?php echo $currency . $order['amount']; ?></td>
                        <td>1</td>
                        <td><?php echo $currency . $order['amount']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="pull-right" style="text-align: right;">
                    <p><strong>Total Amount:</strong> <?php echo $currency . $total_amount; ?></p>
                    <p><strong>Amount Paid:</strong> <?php echo $currency . $amount_paid; ?></p>
                    <p><strong>Balance:</strong> <?php echo $currency . $balance; ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div style="margin-left:40%;"><b>Staff Sign</b></div><br />
                <div style="margin-left:40%;"><b>Customer Sign</b></div>
            </div>
        </div>

    </div>

    <div class="pull-right">
        <a href="#" onClick="printContent('ass')" class="btn btn-info"><i class="icon-print icon-large"></i> Print</a>
    </div>

</div><!-- contentpanel -->

<?php
include ('footer.php');
?>

<script src="js/jquery.datatables.min.js"></script>
<script src="js/select2.min.js"></script>

<script>
    jQuery(document).ready(function() {

        "use strict";

        jQuery('#table1').dataTable();

        jQuery('#table2').dataTable({
            "sPaginationType": "full_numbers"
        });

        // Select2
        jQuery('select').select2({
            minimumResultsForSearch: -1
        });

        jQuery('select').removeClass('form-control');

        // Delete row in a table
        jQuery('.delete-row').click(function() {
            var c = confirm("Continue delete?");
            if (c)
                jQuery(this).closest('tr').fadeOut(function() {
                    jQuery(this).remove();
                });

            return false;
        });

        // Show action upon row hover
        jQuery('.table-hidaction tbody tr').hover(function() {
            jQuery(this).find('.table-action-hide a').animate({
                opacity: 1
            });
        }, function() {
            jQuery(this).find('.table-action-hide a').animate({
                opacity: 0
            });
        });

    });
</script>

</body>
</html>
