<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

$user = $_SESSION['username'];
$usid = $pdo->query("SELECT id FROM users WHERE username='" . $user . "'");
$usid = $usid->fetch(PDO::FETCH_ASSOC);
$uid = $usid['id'];
include('header.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Customer</title>
    <link rel="stylesheet" href="css/style.default.css">
    <style>
        .content-wrapper {
            margin: 20px;
        }

        .form-container {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
        }

        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            border-color: #80bdff;
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }

        .btn-submit {
            background-color: #28a745;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-submit:hover {
            background-color: #218838;
        }

        .alert {
            padding: 15px;
            border: 1px solid transparent;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }

        .page-header {
            margin-bottom: 30px;
        }

        .page-header h1 {
            font-size: 2rem;
            color: #343a40;
        }

    </style>
</head>
<body>
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Add Customer</h1>
            </div>
        </div>
        <div class="row content-wrapper">
            <div class="col-md-10 col-md-offset-1 form-container">
                <?php
                if ($_POST) {
                    $fullname = $_POST["fullname"];
                    $address = $_POST["address"];
                    $phonenumber = $_POST["phonenumber"];
                    $sex = $_POST["sex"];
                    $email = $_POST["email"];
                    $city = $_POST["city"];
                    $comment = $_POST["comment"];

                    $res = $pdo->exec("INSERT INTO customer SET fullname='" . $fullname . "', address='" . $address . "', phonenumber='" . $phonenumber . "', sex='" . $sex . "', email='" . $email . "', city='" . $city . "', comment='" . $comment . "'");
                    $cid = $pdo->lastInsertId();
                    if ($res) {
                        echo "<div class='alert alert-success alert-dismissable'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                        Customer Added Successfully!
                        </div>
                        <meta http-equiv='refresh' content='2; url=addmeasurement.php?id=$cid' />";
                    }
                }
                ?>
                <form id="customerForm" action="customeradd.php" method="post" onsubmit="return validateForm()">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" id="fullname" name="fullname" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <input type="text" id="address" name="address" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="text" id="phonenumber" name="phonenumber" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" id="city" name="city" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="email" name="email" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Comment</label>
                        <textarea id="comment" name="comment" rows="4" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Sex</label>
                        <select id="sex" name="sex" class="form-control">
                            <option value="0">Male</option>
                            <option value="1">Female</option>
                        </select>
                    </div>
                    <input type="submit" class="btn btn-submit" value="ADD">
                </form>
            </div>
        </div>
    </div>

    <?php include('footer.php'); ?>

    <script src="js/jquery.datatables.min.js"></script>
    <script src="js/select2.min.js"></script>
    <script src="js/bootstrap-timepicker.min.js"></script>
    <script>
        jQuery(document).ready(function(){
            "use strict";

            jQuery('#table1').dataTable();
            jQuery('#table2').dataTable({
                "sPaginationType": "full_numbers"
            });

            // Select2
            jQuery('select').select2({
                minimumResultsForSearch: -1
            });
            jQuery('select').removeClass('form-control');

            // Delete row in a table
            jQuery('.delete-row').click(function(){
                var c = confirm("Continue delete?");
                if(c)
                    jQuery(this).closest('tr').fadeOut(function(){
                        jQuery(this).remove();
                    });
                return false;
            });

            // Show action upon row hover
            jQuery('.table-hidaction tbody tr').hover(function(){
                jQuery(this).find('.table-action-hide a').animate({opacity: 1});
            },function(){
                jQuery(this).find('.table-action-hide a').animate({opacity: 0});
            });

            // Time Picker
            jQuery('#timepicker').timepicker({defaultTIme: false});
            jQuery('#timepicker2').timepicker({showMeridian: false});
            jQuery('#timepicker3').timepicker({minuteStep: 15});
        });

        function validateForm() {
            let isValid = true;
            const fields = ['fullname', 'address', 'phonenumber', 'city', 'email', 'comment', 'sex'];
            fields.forEach(field => {
                const value = document.getElementById(field).value.trim();
                if (!value) {
                    alert('Please fill in all the fields.');
                    document.getElementById(field).focus();
                    isValid = false;
                    return false;
                }
            });
            return isValid;
        }
    </script>
</body>
</html>
