<?php
session_start(); // Start session (if not already started)

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection
    include('db_connection.php');

    // Function to sanitize input data
    function sanitize_input($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    // Validate and sanitize input data
    $fullname = sanitize_input($_POST['fullname']);
    $email = sanitize_input($_POST['email']);
    $phone = sanitize_input($_POST['phone']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Prepare SQL statement with placeholders
    $query = "INSERT INTO password (fullname, email, phone, password) VALUES (?, ?, ?, ?)";
    
    // Prepare and bind the statement
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("ssss", $fullname, $email, $phone, $password);
        
        // Execute the statement
        if ($stmt->execute()) {
            $stmt->close();
            
            // Automatically log in the user after successful signup
            $_SESSION['fullname'] = $fullname;
            $_SESSION['email'] = $email;
            $_SESSION['phone'] = $phone;

            // Redirect to order tracking page
            header('Location: order_tracking.php');
            exit();
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    // Close the database connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customer Login & Signup page</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

  <div class="wrapper">
    <div class="form-wrapper sign-in">
      <form action="login.php" method="POST">
        <h2>Login</h2>
        <div class="input-group">
          <input type="text" name="email" required>
          <label for="">Email</label>
        </div>
        <div class="input-group">
          <input type="password" name="password" required>
          <label for="">Password</label>
        </div>
        <div class="remember">
          <label><input type="checkbox" name="remember"> Remember me</label>
        </div>
        <button type="submit">Login</button>
        <div class="signUp-link">
          <p>Don't have an account? <a href="#" class="signUpBtn-link">Sign Up</a></p>
        </div>
      </form>
    </div>

    <div class="form-wrapper sign-up">
      <form action="signup.php" method="POST">
        <h2>Sign Up</h2>
        <div class="input-group">
          <input type="text" name="fullname" required>
          <label for="">Full Name</label>
        </div>
        <div class="input-group">
          <input type="email" name="email" required>
          <label for="">Email</label>
        </div>
        <div class="input-group">
          <input type="tel" name="phone" required>
          <label for="">Phone</label>
        </div>
        <div class="input-group">
          <input type="password" name="password" required>
          <label for="">Password</label>
        </div>
        <div class="remember">
          <label><input type="checkbox" required> I agree to the terms & conditions</label>
        </div>
        <button type="submit">Sign Up</button>
        <div class="signUp-link">
          <p>Already have an account? <a href="#" class="signInBtn-link">Sign In</a></p>
        </div>
      </form>
    </div>
  </div>

  <script src="script.js"></script>
</body>

</html>