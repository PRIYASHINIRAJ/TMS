<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

// Fetch all data from the inventory table
$stmt = $pdo->query("SELECT * FROM inventory");
$inventory = $stmt->fetchAll(PDO::FETCH_ASSOC);

include('header.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #85C1E9;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #85C1E9;
            color: white;
        }

        img {
            width: 50px;
            height: 50px;
            object-fit: cover;
        }

        .available {
            color: green;
        }

        .not-available {
            color: red;
        }

        input[type="number"] {
            width: 60px;
        }

        input[type="submit"] {
            background-color: #85C1E9;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #3498db;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Inventory Management System</h1>
        <table id="inventoryTable">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Availability</th>
                    <th>Quantity</th>
                    <th>Picture</th>
                    <th>Date Added/Updated</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($inventory)) {
                    foreach ($inventory as $row) {
                        echo "<tr>";
                        echo "<td>{$row['product_name']}</td>";
                        echo "<td class='" . strtolower(str_replace(' ', '-', $row['availability'])) . "'>{$row['availability']}</td>";
                        echo "<td><form method='post' action=''>";
                        echo "<input type='number' name='quantity' value='{$row['quantity']}'></td>";
                        echo "<td><img src='{$row['picture_url']}' alt='{$row['product_name']}'></td>";
                        echo "<td>{$row['date_added']}</td>";
                        echo "<td>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                <input type='hidden' name='update' value='1'>
                                <input type='submit' value='Update'>
                              </form></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No records found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <?php include('footer.php'); ?>

    <!-- Handle Form Submission -->
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
        $id = $_POST['id'];
        $quantity = $_POST['quantity'];

        // Example update query - replace with your actual update logic
        $stmt = $pdo->prepare("UPDATE inventory SET quantity = :quantity WHERE id = :id");
        $stmt->execute(['quantity' => $quantity, 'id' => $id]);

        // Redirect to prevent form resubmission on page refresh
        header("Location: inventory.php");
        exit();
    }
    ?>
</body>
</html>
