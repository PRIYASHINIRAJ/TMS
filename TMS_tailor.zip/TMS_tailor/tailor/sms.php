<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

if ($_POST) {
    $customer = $_POST["customer"];
    
    // Fetch customer phone number from database
    $stmt = $pdo->prepare("SELECT phonenumber FROM customer WHERE fullname = :fullname");
    $stmt->execute(['fullname' => $customer]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $phone = $result['phonenumber'];

    // Ensure phone number has a valid country code (e.g., +60 for Malaysia)
    $country_code = "+60"; // Malaysia country code example

    // Check if phone number starts with a valid country code
    if (!startsWith($phone, '+')) {
        $phone = $country_code . ltrim($phone, '0'); // Append country code if missing and remove leading zero
    }

    // Construct WhatsApp message
    $whatsapp_message = "Dear $customer, thank you for choosing RajesCreation. Your order has been finished and is ready for collection. Please collect it as soon as possible.";
    
    // Redirect to WhatsApp with the customer's phone number and message
    $whatsapp_url = "https://api.whatsapp.com/send?phone=" . urlencode($phone) . "&text=" . urlencode($whatsapp_message);

    // Redirect to WhatsApp
    echo "<script>window.location.href = '$whatsapp_url';</script>";
    exit;
}

function startsWith($haystack, $needle) {
    return $needle !== '' && strpos($haystack, $needle) === 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send SMS</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<?php include ('header.php'); ?>

<div id="page-wrapper" class="container mt-5">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Send SMS</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <form action="sms.php" method="post">
                <div class="form-group">
                    <label for="customer">Select Customer</label>
                    <select name="customer" id="customer" class="form-control">
                        <option value="0">Please Select a Customer</option>
                        <?php
                        $ddaa = $pdo->query("SELECT id, fullname FROM customer ORDER BY id");
                        while ($data = $ddaa->fetch(PDO::FETCH_ASSOC)) {
                            echo "<option value='$data[fullname]'>$data[fullname]</option>";
                        }
                        ?>
                    </select>
                </div>

                <input type="submit" class="btn btn-lg btn-success btn-block" value="OPEN WHATSAPP">
            </form>
        </div>
    </div>
</div>

<?php include ('footer.php'); ?>

<!-- Include Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
