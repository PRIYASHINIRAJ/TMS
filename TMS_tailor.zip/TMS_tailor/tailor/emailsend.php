<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

include('header.php');

$user = $_SESSION['username'];
$usid = $pdo->query("SELECT id FROM users WHERE username='".$user."'");
$usid = $usid->fetch(PDO::FETCH_ASSOC);
$uid = $usid['id'];
?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Send EMAIL</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <form id="emailForm">
                <div class="form-group">
                    <label>Name of Recipient</label>
                    <input name="customer" id='customer' class="form-control"><br/>
                </div>

                <div class="form-group">
                    <label>Email Address</label>
                    <input name="toemail" id='toemail' type="email" class="form-control"><br/>
                </div>

                <div class="form-group">
                    <label>Select a Template</label>
                    <select name="template" id='template' class="form-control">
                        <option value="0">Please Select a Template</option>
                        <?php
                        $templates = $pdo->query("SELECT id, title, msg FROM template ORDER BY id");
                        while ($data = $templates->fetch(PDO::FETCH_ASSOC)) {
                            echo "<option value='{$data['title']}' data-message='{$data['msg']}'>{$data['title']}</option>";
                        }
                        ?>
                    </select><br/>
                </div>

                <div class="form-group">
                    <label>Message</label><br/>
                    <textarea rows="4" name="message" id='message' class="form-control"></textarea><br/><br/>
                </div>

                <input type="submit" class="btn btn-lg btn-success btn-block" value="SEND">
            </form>
        </div>
    </div>
</div>

<script>
    document.getElementById("emailForm").onsubmit = function() {
        var customerName = encodeURIComponent(document.getElementById("customer").value);
        var customerEmail = encodeURIComponent(document.getElementById("toemail").value);
        var templateMessage = encodeURIComponent(document.getElementById("template").options[document.getElementById("template").selectedIndex].getAttribute('data-message'));
        
        var subject = encodeURIComponent("Collect your Clothes");
        var body = `Dear ${customerName},\n\n${templateMessage}`;
        
        var mailtoLink = `mailto:${customerEmail}?subject=${subject}&body=${body}`;
        
        window.location.href = mailtoLink;
        
        return false; // Prevent form submission
    };

    // Auto-populate message based on selected template
    document.getElementById("template").onchange = function () {
        var templateMessage = this.options[this.selectedIndex].getAttribute('data-message');
        var customerName = document.getElementById("customer").value;
        document.getElementById("message").value = `Dear ${customerName},\n\n${templateMessage}`;
    };
</script>

<?php
include('footer.php');
?>
