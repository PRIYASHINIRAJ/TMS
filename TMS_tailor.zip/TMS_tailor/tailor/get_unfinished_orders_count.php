<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tailor";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch count of unfinished orders
$query = "SELECT COUNT(*) as count FROM `order` WHERE completed != 'Yes'";
$result = $conn->query($query);
$row = $result->fetch_assoc();
echo $row['count'];

$conn->close();
?>
