<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php
    $title = "Admin Login";
    if (isset($_GET['message']) && $_GET['message'] == 'Signup successful. Please login as Customer.') {
        $title = "Customer Login";
    }
    ?>
    <title><?php echo $title; ?></title>

    <!-- CSS -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800,900&display=swap">
    
    <style>
        /* Original Styles */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: #25252b;
            font-family: 'Roboto', sans-serif;
            color: #fff;
        }

        /* New Styles */
        @property --a {
            syntax: '<angle>';
            inherits: false;
            initial-value: 0deg;
        }

        .box {
            position: relative;
            width: 400px;
            height: 200px;
            background: repeating-conic-gradient(from var(--a), #45f3ff 0%, #45f3ff 5%, transparent 5%, transparent 40%, #45f3ff 50%);
            filter: drop-shadow(0 15px 50px #000);
            border-radius: 20px;
            animation: rotating 4s linear infinite;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: 0.5s;
        }

        .box:hover {
            width: 450px;
            height: 500px;
        }

        @keyframes rotating {
            0% {
                --a: 0deg;
            }
            100% {
                --a: 360deg;
            }
        }

        .box::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: repeating-conic-gradient(from var(--a), #099FFF 0%, #099FFF 5%, transparent 5%, transparent 40%, #099FFF 50%);
            filter: drop-shadow(0 15px 50px #000);
            border-radius: 20px;
            animation: rotating 4s linear infinite;
            animation-delay: -1s;
        }

        .box::after {
            content: '';
            position: absolute;
            inset: 4px;
            background: #2d2d39;
            border-radius: 15px;
            border: 8px solid #25252b;
        }

        .login {
            position: absolute;
            inset: 60px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            border-radius: 10px;
            background: rgba(0, 0, 0, 0.2);
            z-index: 1000;
            box-shadow: inset 0 10px 20px rgba(0, 0, 0, 0.5);
            border-bottom: 2px solid rgba(255, 255, 255, 0.5);
            transition: 0.5s;
            color: #fff;
            overflow: hidden;
        }

        .box:hover .login {
            inset: 40px;
        }

        .loginBx {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            gap: 20px;
            width: 70%;
            transform: translateY(126px);
            transition: 0.5s;
        }

        .box:hover .loginBx {
            transform: translateY(0px);
        }

        .loginBx h2 {
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.2em;
            font-size: 1.5em; /* Adjusted font size */
        }

        .loginBx h2 i {
            color: #ff2770;
            text-shadow: 0 0 5px #ff2770, 0 0 25px #ff2770;
        }

        .loginBx input {
            width: 100%;
            padding: 10px 20px;
            margin-bottom: 15px;
            outline: none;
            border: none;
            font-size: 1em;
            color: #fff;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid #fff;
            border-radius: 30px;
        }

        .loginBx input::placeholder {
            color: #999;
        }

        .loginBx input[type="submit"] {
            background: #45f3ff;
            border: none;
            font-weight: 500;
            color: #111;
            cursor: pointer;
            transition: 0.5s;
        }

        .loginBx input[type="submit"]:hover {
            box-shadow: 0 0 10px #45f3ff, 0 0 60px #45f3ff;
        }

        .group {
            width: 100%;
            display: flex;
            justify-content: space-between;
        }

        .group a {
            color: #fff;
            text-decoration: none;
        }

        .group a:nth-child(2) {
            color: #ff2770;
            font-weight: 600;
        }
    </style>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <!-- Top content -->
    <div class="box">
        <div class="login">
            <div class="loginBx">
                <h2><i class="fa fa-user"></i> <?php echo $title; ?></h2>
                <?php if (!empty($_GET['error'])): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>    
                        <?php echo $_GET['error']?>
                    </div>
                <?php endif ?>
                <form role="form" action="<?php echo ($title == 'Customer Login') ? 'customer_login.php' : 'signin_post.php'; ?>" method="post" class="registration-form">
                    <?php if ($title == "Customer Login"): ?>
                    <div class="form-group">
                        <input type="email" name="email" class="form-first-name form-control" placeholder="Email">
                    </div>
                    <?php else: ?>
                    <div class="form-group">
                        <input type="text" name="username" value="admin" class="form-first-name form-control" placeholder="Username">
                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <input type="password" name="password" class="pass form-control" placeholder="Password">
                    </div>
                    <div class="group">
                        <a href="#"></a>
                        <a href="signup.php">Customer Sign Up!</a> <!-- Link to signup.php -->
                    </div>
                    <input type="submit" class="btn" value="Submit">
                </form>
            </div>
        </div>
    </div>

    <!-- Javascript -->
    <script src="assets/js/jquery-1.11.1.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.backstretch.min.js"></script>
    <script src="assets/js/retina-1.1.0.min.js"></script>
    <script src="assets/js/scripts.js"></script>

    <!--[if lt IE 10]>
        <script src="assets/js/placeholder.js"></script>
    <![endif]-->

</body>
</html>
